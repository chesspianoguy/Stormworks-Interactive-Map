const test = require('node:test');
const assert = require('node:assert');
const { createAssembler } = require('../server/snapshot');

function setup() {
  const done = [];
  const logs = [];
  const a = createAssembler({ onComplete: (kind, obj) => done.push({ kind, obj }), log: (m) => logs.push(m) });
  return { a, done, logs };
}

// Split an encoded string into parts the way the addon does.
function parts(obj, size = 7) {
  const enc = encodeURIComponent(JSON.stringify(obj));
  const out = [];
  for (let i = 0; i < enc.length; i += size) out.push(enc.slice(i, i + size));
  return out;
}

function send(a, s, chunks, order = chunks.map((_, i) => i)) {
  a.handle('/sw/begin', { s, n: String(chunks.length) });
  for (const i of order) a.handle('/sw/part', { s, i: String(i), d: chunks[i] });
  a.handle('/sw/end', { s });
}

test('in order', () => {
  const { a, done } = setup();
  send(a, '1', parts({ kind: 'snap', v: 1 }));
  assert.deepStrictEqual(done, [{ kind: 'snap', obj: { kind: 'snap', v: 1 } }]);
});

test('out of order', () => {
  const { a, done } = setup();
  const c = parts({ kind: 'snap', list: [1, 2, 3, 4, 5] });
  send(a, '2', c, c.map((_, i) => i).reverse());
  assert.deepStrictEqual(done[0].obj.list, [1, 2, 3, 4, 5]);
});

test('missing chunk never completes', () => {
  const { a, done, logs } = setup();
  const c = parts({ kind: 'snap', v: 'abcdefghijkl' });
  a.handle('/sw/begin', { s: '3', n: String(c.length) });
  a.handle('/sw/part', { s: '3', i: '0', d: c[0] });
  a.handle('/sw/end', { s: '3' });
  assert.strictEqual(done.length, 0);
  assert.ok(logs.some((l) => /missing/.test(l)));
});

test('duplicate chunk', () => {
  const { a, done } = setup();
  const c = parts({ kind: 'snap', v: 'x'.repeat(20) });
  const order = [0, 0, ...c.map((_, i) => i)];
  send(a, '4', c, order);
  assert.strictEqual(done.length, 1);
  assert.strictEqual(done[0].obj.v, 'x'.repeat(20));
});

test('split inside escape', () => {
  const { a, done } = setup();
  const enc = encodeURIComponent(JSON.stringify({ kind: 'snap', n: 'é' }));
  const at = enc.indexOf('%C3') + 2;  // "%C" | "3%A9..."
  send(a, '5', [enc.slice(0, at), enc.slice(at)]);
  assert.strictEqual(done[0].obj.n, 'é');
});

test('decodes percent-encoded unicode', () => {
  const { a, done } = setup();
  const name = 'Bob & "Ann" 100% 🚁';
  send(a, '6', parts({ kind: 'snap', name }, 3));
  assert.strictEqual(done[0].obj.name, name);
});

test('bad json logged not thrown', () => {
  const { a, done, logs } = setup();
  send(a, '7', [encodeURIComponent('{not json')]);
  assert.strictEqual(done.length, 0);
  assert.ok(logs.some((l) => /json/i.test(l)));
});

test('unknown snapshot id ignored', () => {
  const { a, done, logs } = setup();
  assert.doesNotThrow(() => a.handle('/sw/part', { s: '99', i: '0', d: 'x' }));
  a.handle('/sw/end', { s: '99' });
  assert.strictEqual(done.length, 0);
  assert.ok(logs.length >= 1);
});

test('non sw path not handled', () => {
  const { a } = setup();
  assert.strictEqual(a.handle('/api/state', {}), false);
  assert.strictEqual(a.handle('/sw/begin', { s: '1', n: '1' }), true);
});

test('non-object payload is dropped, not thrown', () => {
  const { a, done, logs } = setup();
  assert.doesNotThrow(() => send(a, '8', [encodeURIComponent('null')]));
  assert.doesNotThrow(() => send(a, '9', [encodeURIComponent('5')]));
  assert.strictEqual(done.length, 0);
  assert.ok(logs.length >= 2);
});

test('huge part count is rejected', () => {
  const { a, logs } = setup();
  a.handle('/sw/begin', { s: '10', n: '1000000000' });
  a.handle('/sw/end', { s: '10' });
  assert.ok(logs.some((l) => /bad args|unknown/.test(l)));
});
