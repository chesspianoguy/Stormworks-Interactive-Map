// Runs addon/script.lua in fengari (Lua 5.3) against a fake Stormworks API and feeds what it
// sends through the real server-side assembler.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { lua, lauxlib, lualib, to_luastring } = require('fengari');
const { createAssembler, rawQuery } = require('../server/snapshot');

const SCRIPT = fs.readFileSync(path.join(__dirname, '..', 'addon', 'script.lua'), 'utf8');

const MOCK = String.raw`
SENT = {}
local function T(x, y, z) return {1,0,0,0, 0,1,0,0, 0,0,1,0, x,y,z,1} end
matrix = {
  translation = T,
  position = function(m) return m[13], m[14], m[15] end,
  multiply = function(a, b)
    local r = {}
    for c = 0, 3 do for row = 1, 4 do
      local s = 0
      for k = 0, 3 do s = s + a[k*4 + row] * b[c*4 + k + 1] end
      r[c*4 + row] = s
    end end
    return r
  end,
}
local tiles = {
  ["-20000,-5000"] = { name = "island_33_tile_32", purchased = true, cost = 0 },
  ["-21000,-5000"] = { name = "island_33_tile_33", purchased = false, cost = 50000 },
  ["-19000,-5000"] = { name = "ocean_deep", purchased = false, cost = 0 },
}
server = {
  httpGet = function(port, p) SENT[#SENT + 1] = p end,
  getTile = function(m) local t = tiles[string.format("%d,%d", m[13], m[15])]; if t then return t, true end; return { name = "" }, false end,
  getAddonCount = function() return 1 end,
  getAddonData = function(i) return { name = "Landmarks", location_count = 2 } end,
  getLocationData = function(a, l)
    if l == 0 then return { name = "Arecibo", tile = "data/tiles/island_33_tile_32.xml", component_count = 1 } end
    return { name = "Env", tile = "", component_count = 0 }
  end,
  getTileTransform = function(m, tile) return T(-20000, 0, -5000), true end,
  getLocationComponentData = function(a, l, c) return { display_name = "Dish", tags_full = "type=landmark", type = 3, transform = T(10, 5, 20) } end,
  getVehiclePos = function(id) if id == 12 or id == 120 then return T(-20045, 20, -4725), true end; return nil, false end,
  getVehicleData = function(id) return { name = 'Heli "X"', mass = 5400, voxels = 3100, simulating = true } end,
  getObjectData = function(id)
    if id == 3535 then return { object_type = 1, name = "Doctor", dead = false } end
    if id == 9100 then return { object_type = 1, name = "Late NPC", dead = false } end
    if id == 40 then return { object_type = 58 } end
    if id == 7 then return { object_type = 24 } end
    return nil
  end,
  getObjectPos = function(id) return T(id, 1, -id), true end,
  getFireData = function(id) return id == 40 end,
  getPlayers = function() return { { id = 0, name = 'Ann \u{e9} & "Co" 100%', steam_id = 76561198000000000, object_id = 99 } } end,
  getPlayerPos = function(peer) return T(-20041.5, 17, -4730.5), true end,
  getCharacterData = function(id) return { v_id = 12 } end,
  getTime = function() return { hour = 14, minute = 30 } end,
  getDate = function() return 2, 5, 2032 end,
  getCurrency = function() return 20000 end,
  getResearchPoints = function() return 12 end,
  getWeather = function(m) return { fog = 0.1, rain = 0.4, wind = 0.3, temp = 18 } end,
}
`;

const SETTINGS = 'TILE_RANGE = 25; VEH_SCAN_MAX = 50; OBJ_SCAN_MAX = 4000; SNAP_TICKS = 10; CHUNK = 50';

function runAddon(ticks, before = '') {
  const L = lauxlib.luaL_newstate();
  lualib.luaL_openlibs(L);
  const run = (code, name) => {
    if (lauxlib.luaL_loadbuffer(L, to_luastring(code), null, to_luastring(name)) || lua.lua_pcall(L, 0, 0, 0)) {
      throw new Error(lua.lua_tojsstring(L, -1));
    }
  };
  run(MOCK, 'mock');
  run(SCRIPT, 'script.lua');
  run(`${SETTINGS}; onCreate(true); ${before}; for i = 1, ${ticks} do onTick() end`, 'driver');
  lua.lua_getglobal(L, to_luastring('SENT'));
  const sent = [];
  const n = lua.lua_rawlen(L, -1);
  for (let i = 1; i <= n; i++) {
    lua.lua_rawgeti(L, -1, i);
    sent.push(lua.lua_tojsstring(L, -1));
    lua.lua_pop(L, 1);
  }
  return sent;
}

function assemble(paths) {
  const msgs = {};
  const logs = [];
  const a = createAssembler({ onComplete: (kind, obj) => { msgs[kind] = obj; }, log: (m) => logs.push(m) });
  for (const p of paths) {
    const q = p.indexOf('?');
    a.handle(p.slice(0, q), rawQuery(p.slice(q + 1)));
  }
  return { msgs, logs };
}

const sent = runAddon(3000);
const { msgs, logs } = assemble(sent);

test('addon sends all three kinds', () => {
  assert.deepStrictEqual(logs, []);
  assert.ok(msgs.layout && msgs.addons && msgs.snap, `got ${Object.keys(msgs)}`);
  assert.ok(sent.every((p) => p.length < 50 + 40), 'chunk size respected');
});

test('layout: grid cells, skips ocean, compact flags', () => {
  const byName = Object.fromEntries(msgs.layout.tiles.map((t) => [t.name, t]));
  assert.deepStrictEqual(Object.keys(byName).sort(), ['island_33_tile_32', 'island_33_tile_33']);
  assert.deepStrictEqual(byName.island_33_tile_32, { cx: -20, cy: -5, name: 'island_33_tile_32', purchased: true });
  assert.strictEqual(byName.island_33_tile_33.cost, 50000);
});

test('addons: world positions, tileless skipped', () => {
  const [ad] = msgs.addons.addons;
  assert.strictEqual(ad.name, 'Landmarks');
  assert.strictEqual(ad.locations.length, 1);
  const [c] = ad.locations[0].components;
  assert.deepStrictEqual([c.x, c.y, c.z], [-19990, 5, -4980]);
  assert.strictEqual(c.name, 'Dish');
});

test('snap: matches fixture shape key-for-key', () => {
  const fixture = JSON.parse(fs.readFileSync(path.join(__dirname, 'fixtures', 'snapshot.json'), 'utf8'));
  const keys = (o) => Object.keys(o).sort();
  assert.deepStrictEqual(keys(msgs.snap), keys(fixture));
  assert.deepStrictEqual(keys(msgs.snap.players[0]), keys(fixture.players[0]));
  assert.deepStrictEqual(keys(msgs.snap.vehicles[0]), keys(fixture.vehicles[0]));
  assert.deepStrictEqual(keys(msgs.snap.chars[0]), keys(fixture.chars[0]));
  assert.deepStrictEqual(keys(msgs.snap.fires[0]), keys(fixture.fires[0]));
  assert.deepStrictEqual(keys(msgs.snap.game), keys(fixture.game));
});

test('snap: values and escaping', () => {
  const { snap } = msgs;
  assert.strictEqual(snap.players[0].name, 'Ann é & "Co" 100%');
  assert.strictEqual(snap.players[0].vehicle, 12);
  assert.strictEqual(typeof snap.players[0].heading, 'number');
  assert.strictEqual(snap.vehicles[0].name, 'Heli "X"');
  assert.strictEqual(snap.vehicles[0].loaded, true);
  assert.deepStrictEqual(snap.chars.map((c) => c.id), [3535], 'only character types');
  assert.deepStrictEqual(snap.fires, [{ id: 40, x: 40, y: 1, z: -40, lit: true }]);
  assert.strictEqual(snap.game.research, 12);
  assert.strictEqual(snap.game.year, 2032);
  assert.strictEqual(snap.game.weather.rain, 0.4);
});

test('ids above the scan limit are tracked from spawn/load callbacks', () => {
  const { msgs: m } = assemble(runAddon(3000, 'onVehicleSpawn(120, 0); onObjectLoad(9100)'));
  assert.deepStrictEqual(m.snap.vehicles.map((v) => v.id).sort((a, b) => a - b), [12, 120]);
  assert.ok(m.snap.chars.some((c) => c.id === 9100 && c.name === 'Late NPC'));
});
