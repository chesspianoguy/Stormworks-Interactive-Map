const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { merge } = require('../server/merge');
const { parseSave } = require('../server/save-parser');
const { readPlaylist } = require('../tools/lib/playlist');

const fx = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n), 'utf8');
const markers = () => import('../web/markers.js');

const save = parseSave(fx('scene-mini.xml'));
const T = 1_700_000_000_000;
const liveState = merge({
  save, saveTime: T, saveName: 'mini', snap: JSON.parse(fx('snapshot.json')), snapTime: T + 1,
  layout: JSON.parse(fx('layout.json')), addons: JSON.parse(fx('addons.json')),
});
const saveOnlyState = merge({ save, saveTime: T, saveName: 'mini', snap: null, snapTime: null, layout: JSON.parse(fx('layout.json')), addons: null });
const builderLocations = readPlaylist(fx('playlist-mini.xml'), 'base');

test('worldToLatLng and tileOrigin', async () => {
  const { worldToLatLng, tileOrigin } = await markers();
  assert.deepStrictEqual(worldToLatLng(100, -200), [-200, 100]);
  assert.deepStrictEqual(tileOrigin(-20, -5), { x: -20000, z: -5000 });
});

test('buildLayers from live state', async () => {
  const { buildLayers, LAYER_IDS } = await markers();
  const L = buildLayers(liveState, builderLocations);
  assert.deepStrictEqual(Object.keys(L).sort(), [...LAYER_IDS].sort());
  assert.strictEqual(L.vehicles.length, 2);
  assert.strictEqual(L.players[0].title, 'Captain "Ann" & Co 🚁');
  assert.deepStrictEqual(L.players[0].latlng, [-4730.5, -20041.5]);
  assert.deepStrictEqual(L.npcs.map((n) => n.title).sort(), ['Doctor', 'Shark']);
  assert.strictEqual(L.fires.length, 1);
  assert.strictEqual(L.tiles.length, 3);
  assert.strictEqual(L.zones.length, 2);
  assert.ok(L.locMods.length >= 1);
  for (const m of L.locMods) assert.match(m.info.source, /^(mod|user):/);
  assert.ok(L.locBase.every((m) => m.info.source === 'base'));
  assert.strictEqual(L.locBase[0].info.addon, 'Default Landmarks');
});

test('location with x null is skipped, not placed at 0,0', async () => {
  const { buildLayers } = await markers();
  const L = buildLayers(liveState, builderLocations);
  const all = [...L.locBase, ...L.locMods];
  assert.ok(!all.some((m) => m.title === 'Lost Place'));
  assert.ok(!all.some((m) => m.latlng[0] === 0 && m.latlng[1] === 0));
});

test('save-only state places builder locations via layout', async () => {
  const { buildLayers } = await markers();
  const L = buildLayers(saveOnlyState, builderLocations);
  assert.strictEqual(L.locBase.length, 1);
  // island_33_tile_32 is cell (-20,-5); first component at local (0, 0, 0)
  assert.deepStrictEqual(L.locBase[0].latlng, [-5000, -20000]);
  assert.strictEqual(L.players[0].title, 'player');
  assert.ok(L.npcs.every((n) => [1, 59].includes(n.info.type)), 'only character/creature objects');
});

test('owned tiles from save and layout, de-duplicated', async () => {
  const { buildLayers } = await markers();
  const L = buildLayers(liveState, builderLocations);
  assert.deepStrictEqual(L.owned.map((o) => o.info.cell), ['-20,-5']);
});

test('no layout: tile-based things are skipped', async () => {
  const { buildLayers } = await markers();
  const s = { ...saveOnlyState, tilesLayout: null };
  const L = buildLayers(s, builderLocations);
  assert.strictEqual(L.tiles.length, 0);
  assert.strictEqual(L.locBase.length, 0);
  assert.strictEqual(L.owned.length, 1, 'owned cells need no layout');
});

test('search finds by title, case-insensitive, max 50', async () => {
  const { buildLayers, buildIndex, search } = await markers();
  const idx = buildIndex(buildLayers(liveState, builderLocations));
  const r = search(idx, 'coast');
  assert.ok(r.some((x) => x.item.title === 'Coastguard Outpost Beginner'));
  assert.strictEqual(r[0].layer, 'zones');
  assert.deepStrictEqual(search(idx, ''), []);
  const many = { ...liveState, zones: { ...liveState.zones, items: Array.from({ length: 80 }, (_, i) => ({ id: i, name: `Dock ${i}`, x: i, z: i, radius: 1 })) } };
  assert.strictEqual(search(buildIndex(buildLayers(many, [])), 'dock').length, 50);
});

test('escapeHtml neutralises markup in names', async () => {
  const { escapeHtml } = await markers();
  assert.strictEqual(escapeHtml('<img src=x onerror="a()"> & \'b\''), '&lt;img src=x onerror=&quot;a()&quot;&gt; &amp; &#39;b&#39;');
  assert.strictEqual(escapeHtml(42), '42');
});
