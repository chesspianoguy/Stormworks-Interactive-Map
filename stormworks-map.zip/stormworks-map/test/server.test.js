const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { startServer } = require('../server/index');
const { sendMessage } = require('../tools/fake-addon');

const fx = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n), 'utf8');

// Raw GET so paths like "/../x" reach the server unnormalized.
function get(port, p) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: p, method: 'GET' }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body, type: res.headers['content-type'] }));
    });
    req.on('error', reject);
    req.end();
  });
}

async function withServer(fn) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'swsrv-'));
  const savesPath = path.join(tmp, 'saves');
  fs.mkdirSync(path.join(savesPath, 'mini'), { recursive: true });
  fs.writeFileSync(path.join(savesPath, 'mini', 'scene.xml'), fx('scene-mini.xml'));
  const server = await startServer({ port: 0, savesPath, cacheDir: path.join(tmp, 'cache'), quiet: true });
  try {
    await fn(server.address().port, server, tmp);
  } finally {
    await new Promise((r) => server.close(r));
  }
}

test('GET /api/state returns merged json', () => withServer(async (port) => {
  const r = await get(port, '/api/state');
  assert.strictEqual(r.status, 200);
  assert.match(r.type, /application\/json/);
  const s = JSON.parse(r.body);
  for (const k of ['generated', 'sources', 'game', 'players', 'vehicles', 'characters', 'fires', 'zones', 'tilesLayout']) {
    assert.ok(k in s, k);
  }
  assert.strictEqual(s.vehicles.source, 'save');
  assert.strictEqual(s.sources.save.name, 'mini');
}));

test('GET /api/saves lists saves', () => withServer(async (port) => {
  const r = JSON.parse((await get(port, '/api/saves')).body);
  assert.deepStrictEqual(r.map((s) => s.name), ['mini']);
}));

test('unknown save name is rejected', () => withServer(async (port) => {
  const r = await get(port, '/api/state?save=..%2F..%2Fetc');
  assert.strictEqual(r.status, 404);
}));

test('static traversal is forbidden', () => withServer(async (port) => {
  assert.strictEqual((await get(port, '/../config.json')).status, 403);
  assert.strictEqual((await get(port, '/map/..%2F..%2Fconfig.json')).status, 403);
  assert.strictEqual((await get(port, '/nope.html')).status, 404);
}));

test('fake addon makes addon the source', () => withServer(async (port) => {
  for (const f of ['layout.json', 'addons.json', 'snapshot.json']) await sendMessage(port, JSON.parse(fx(f)), 1000);
  const s = JSON.parse((await get(port, '/api/state')).body);
  assert.strictEqual(s.vehicles.source, 'addon');
  assert.strictEqual(s.players.items[0].name, 'Captain "Ann" & Co 🚁');
  assert.strictEqual(s.tilesLayout.length, 3);
}));

test('/sw/end asks for missing layout and addons', () => withServer(async (port, server, tmp) => {
  const first = await sendMessage(port, JSON.parse(fx('snapshot.json')), 1000);
  assert.strictEqual(first, 'need:layout,addons');
  await sendMessage(port, JSON.parse(fx('layout.json')), 1000);
  const second = await sendMessage(port, JSON.parse(fx('addons.json')), 1000);
  assert.strictEqual(second, 'ok');
  assert.ok(fs.existsSync(path.join(tmp, 'cache', 'layout.json')), 'layout persisted');
}));

test('cached layout survives restart', () => withServer(async (port, server, tmp) => {
  await sendMessage(port, JSON.parse(fx('layout.json')), 1000);
  const again = await startServer({ port: 0, savesPath: path.join(tmp, 'saves'), cacheDir: path.join(tmp, 'cache'), quiet: true });
  try {
    const s = JSON.parse((await get(again.address().port, '/api/state')).body);
    assert.strictEqual(s.tilesLayout.length, 3);
  } finally {
    await new Promise((r) => again.close(r));
  }
}));

test('listen address is 127.0.0.1', () => withServer(async (port, server) => {
  assert.strictEqual(server.address().address, '127.0.0.1');
}));

function getWith(port, p, headers) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: p, method: 'GET', headers }, (res) => {
      res.resume();
      res.on('end', () => resolve(res.statusCode));
    });
    req.on('error', reject);
    req.end();
  });
}

test('cross-site and foreign-host requests are refused', () => withServer(async (port) => {
  assert.strictEqual(await getWith(port, '/sw/begin?s=1&n=1', { Origin: 'https://evil.example' }), 403);
  assert.strictEqual(await getWith(port, '/sw/begin?s=1&n=1', { 'Sec-Fetch-Site': 'cross-site' }), 403);
  assert.strictEqual(await getWith(port, '/api/state', { Host: 'evil.example:37037' }), 403);
  assert.strictEqual(await getWith(port, '/api/state', { Host: `localhost:${port}` }), 200);
  assert.strictEqual(await getWith(port, '/api/state', { 'Sec-Fetch-Site': 'same-origin' }), 200);
}));

test('null payload does not crash the server', () => withServer(async (port) => {
  await sendMessage(port, null, 1000);
  assert.strictEqual((await get(port, '/api/state')).status, 200);
}));

test('tile names from the addon are normalised', () => withServer(async (port) => {
  await sendMessage(port, { kind: 'layout', tiles: [{ cx: 1, cy: 2, name: 'data/tiles/island_33_tile_32.xml' }] }, 1000);
  await sendMessage(port, { kind: 'addons', addons: [{ index: 0, name: 'A', locations: [{ name: 'L', tile: 'data\\tiles\\arid_island_6_5.xml', components: [] }] }] }, 1000);
  const s = JSON.parse((await get(port, '/api/state')).body);
  assert.strictEqual(s.tilesLayout[0].name, 'island_33_tile_32');
  assert.strictEqual(s.addons[0].locations[0].tile, 'arid_island_6_5');
}));

test('explicitly picking an older save ignores live addon data', () => withServer(async (port, server, tmp) => {
  const older = path.join(tmp, 'saves', 'older');
  fs.mkdirSync(older);
  fs.writeFileSync(path.join(older, 'scene.xml'), fx('scene-mini.xml'));
  const past = new Date(Date.now() - 86400e3);
  fs.utimesSync(path.join(older, 'scene.xml'), past, past);
  await sendMessage(port, JSON.parse(fx('snapshot.json')), 1000);
  const picked = JSON.parse((await get(port, '/api/state?save=older')).body);
  assert.strictEqual(picked.vehicles.source, 'save');
  const newest = JSON.parse((await get(port, '/api/state')).body);
  assert.strictEqual(newest.vehicles.source, 'addon');
}));
