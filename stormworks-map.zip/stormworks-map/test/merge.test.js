const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { merge } = require('../server/merge');
const { parseSave } = require('../server/save-parser');

const fx = (n) => fs.readFileSync(path.join(__dirname, 'fixtures', n), 'utf8');
const save = parseSave(fx('scene-mini.xml'));
const snap = JSON.parse(fx('snapshot.json'));
const layout = JSON.parse(fx('layout.json'));
const addons = JSON.parse(fx('addons.json'));
const saveTime = 1_700_000_000_000;

test('addon newer wins', () => {
  const s = merge({ save, saveTime, saveName: 'mini', snap, snapTime: saveTime + 1, layout, addons });
  assert.strictEqual(s.vehicles.source, 'addon');
  assert.strictEqual(s.vehicles.items.length, 2);
  assert.strictEqual(s.characters.source, 'addon');
  assert.strictEqual(s.characters.items[0].name, 'Doctor', 'snap.chars maps to characters');
  assert.strictEqual(s.game.source, 'addon');
  assert.strictEqual(s.game.items.research, 12);
  assert.strictEqual(s.zones.source, 'save', 'zones always from save');
  assert.deepStrictEqual(s.purchasedTiles, [{ cx: -20, cy: -5 }]);
  assert.strictEqual(s.tilesLayout.length, 3);
  assert.strictEqual(s.addons.length, 2);
  assert.strictEqual(s.sources.save.name, 'mini');
});

test('stale addon loses to newer save', () => {
  const s = merge({ save, saveTime, saveName: 'mini', snap, snapTime: saveTime - 3600e3, layout, addons });
  assert.strictEqual(s.vehicles.source, 'save');
  assert.strictEqual(s.players.source, 'save');
  assert.strictEqual(s.players.items[0].name, 'player');
  assert.strictEqual(s.sources.addon.time, saveTime - 3600e3);
});

test('no addon at all', () => {
  const s = merge({ save, saveTime, saveName: 'mini', snap: null, snapTime: null, layout: null, addons: null });
  for (const k of ['players', 'vehicles', 'characters', 'fires', 'game']) assert.strictEqual(s[k].source, 'save', k);
  assert.strictEqual(s.tilesLayout, null);
  assert.strictEqual(s.addons, null);
  assert.strictEqual(s.sources.addon, null);
});

test('no save at all', () => {
  const s = merge({ save: null, saveTime: null, snap, snapTime: saveTime, layout, addons });
  assert.strictEqual(s.vehicles.source, 'addon');
  assert.deepStrictEqual(s.zones.items, []);
  assert.deepStrictEqual(s.purchasedTiles, []);
  assert.strictEqual(s.sources.save, null);
});

test('nothing at all', () => {
  const s = merge({ save: null, saveTime: null, snap: null, snapTime: null, layout: null, addons: null });
  assert.strictEqual(s.vehicles.source, null);
  assert.deepStrictEqual(s.vehicles.items, []);
});

test('layout purchased flags merge into purchasedTiles', () => {
  const s = merge({ save: null, saveTime: null, snap, snapTime: saveTime, layout, addons });
  assert.deepStrictEqual(s.tilesLayout.filter((t) => t.purchased).map((t) => t.name), ['island_33_tile_32']);
});
