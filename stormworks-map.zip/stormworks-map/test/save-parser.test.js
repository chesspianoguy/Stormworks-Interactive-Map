const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { parseSave, loadSave, listSaves } = require('../server/save-parser');
const { loadConfig } = require('../server/config');

const miniText = fs.readFileSync(path.join(__dirname, 'fixtures', 'scene-mini.xml'), 'utf8');

function tempSave(text = miniText, name = 'mini') {
  const dir = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'swsave-')), name);
  fs.mkdirSync(dir);
  fs.writeFileSync(path.join(dir, 'scene.xml'), text);
  return dir;
}

test('parses mini scene', () => {
  const s = parseSave(miniText);
  assert.strictEqual(s.player.x, -20041.557097);
  assert.strictEqual(s.player.z, -4730.506192);
  assert.strictEqual(s.game.money, 20000);
  assert.strictEqual(s.game.day, 2);
  assert.strictEqual(s.game.dayTick, 70552);
  assert.strictEqual(s.vehicles.length, 2);
  assert.strictEqual(s.vehicles[0].tags, 'lift_airstrip');
  assert.strictEqual(s.vehicles[0].isMission, true);
  assert.strictEqual(s.vehicles[1].y, 0, 'missing transform attr = 0');
  assert.strictEqual(s.zones[0].name, 'Coastguard Outpost Beginner');
  assert.strictEqual(s.zones[0].radius, 2.5);
  assert.strictEqual(s.zones[1].name, 'type=dock', 'blank display_name falls back to tags');
  assert.deepStrictEqual(s.purchasedTiles, [{ cx: -20, cy: -5 }]);
  assert.strictEqual(s.discoveredTiles.length, 2);
  assert.ok(s.playlists.includes('rom/data/missions/default_ai'));
  assert.strictEqual(s.mods.length, 1);
  assert.strictEqual(s.characters.length, 3, 'all object types kept');
  const doc = s.characters.find((c) => c.type === 1);
  assert.strictEqual(doc.name, 'Doctor & Nurse');
  assert.strictEqual(doc.x, 101.060081);
  assert.deepStrictEqual(s.fires.map((f) => f.id), [40], 'fire objects (type 58)');
  assert.strictEqual(s.addonNodes[0].tags, 'ocean_path');
  assert.strictEqual(s.addonNodes[0].z, -12500);
});

test('missing sections give empty arrays', () => {
  const s = parseSave('<?xml version="1.0"?><scene version="4"><game_data/></scene>');
  assert.deepStrictEqual(s.vehicles, []);
  assert.deepStrictEqual(s.zones, []);
  assert.strictEqual(s.player, null);
});

test('real autosave', (t) => {
  const dir = path.join(loadConfig().savesPath, 'autosave');
  if (!fs.existsSync(path.join(dir, 'scene.xml'))) return t.skip('no autosave');
  const t0 = Date.now();
  const { state, error } = loadSave(dir);
  const ms = Date.now() - t0;
  assert.strictEqual(error, undefined);
  assert.ok(state.vehicles.length > 0);
  assert.ok(state.zones.length > 1000);
  assert.ok(ms < 3000, `parse took ${ms} ms`);
});

test('partial file keeps last good', () => {
  const dir = tempSave();
  const first = loadSave(dir);
  assert.strictEqual(first.error, undefined);
  const file = path.join(dir, 'scene.xml');
  fs.writeFileSync(file, miniText.slice(0, Math.floor(miniText.length / 2)));
  const later = new Date(Date.now() + 5000);
  fs.utimesSync(file, later, later);
  const second = loadSave(dir);
  assert.strictEqual(second.state, first.state);
  assert.ok(second.error);
});

test('cache hit skips reparse', () => {
  const dir = tempSave();
  const a = loadSave(dir);
  const b = loadSave(dir);
  assert.strictEqual(a.state, b.state);
});

test('listSaves newest first, only dirs with scene.xml', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'swsaves-'));
  for (const [name, age] of [['old', 100], ['new', 1]]) {
    fs.mkdirSync(path.join(root, name));
    const f = path.join(root, name, 'scene.xml');
    fs.writeFileSync(f, miniText);
    const t = new Date(Date.now() - age * 1000);
    fs.utimesSync(f, t, t);
  }
  fs.mkdirSync(path.join(root, 'empty'));
  assert.deepStrictEqual(listSaves(root).map((s) => s.name), ['new', 'old']);
});

test('repeated refresh after bad save still reports last good time', () => {
  const dir = tempSave();
  const first = loadSave(dir);
  const file = path.join(dir, 'scene.xml');
  fs.writeFileSync(file, miniText.slice(0, 100));
  const later = new Date(Date.now() + 5000);
  fs.utimesSync(file, later, later);
  loadSave(dir);
  const third = loadSave(dir);
  assert.strictEqual(third.state, first.state);
  assert.strictEqual(third.mtime, first.mtime);
  assert.ok(third.error);
});
