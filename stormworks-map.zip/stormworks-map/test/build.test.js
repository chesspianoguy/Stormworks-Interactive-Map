const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { readTileXml } = require('../tools/lib/tile-xml');
const { readPlaylist } = require('../tools/lib/playlist');
const { readTxtr, encodePng } = require('../tools/lib/txtr');
const { mergeSources } = require('../tools/build-map');
const { loadConfig } = require('../server/config');

const fixture = (name) => fs.readFileSync(path.join(__dirname, 'fixtures', name), 'utf8');

test('tile xml with numeric attrs parses', () => {
  assert.deepStrictEqual(readTileXml(fixture('tile-mini.xml')), {
    isIsland: true, purchasable: true, cost: 200000,
  });
});

test('playlist locations', () => {
  const locs = readPlaylist(fixture('playlist-mini.xml'), 'base');
  assert.strictEqual(locs.length, 1, 'tileless env-only location is skipped');
  const [loc] = locs;
  assert.strictEqual(loc.name, 'ARECIBO & CO');
  assert.strictEqual(loc.tile, 'island_33_tile_32');
  assert.strictEqual(loc.source, 'base');
  assert.strictEqual(loc.addon, 'Default Landmarks');
  assert.strictEqual(loc.components.length, 2);
  assert.strictEqual(loc.components[1].x, 64.4);
  assert.strictEqual(loc.components[1].z, -0.8);
  assert.strictEqual(loc.components[0].x, 0, 'missing transform attr = 0');
  assert.strictEqual(loc.components[0].name, 'Dish', 'display_name preferred');
  assert.strictEqual(loc.components[1].name, 'tourist', 'falls back to name');
});

test('txtr round trip', (t) => {
  const file = path.join(loadConfig().gamePath, 'rom/graphics/ui/map/atlas_mapicons.txtr');
  if (!fs.existsSync(file)) return t.skip('no game files');
  const img = readTxtr(fs.readFileSync(file));
  assert.strictEqual(img.w, 1024);
  assert.strictEqual(img.h, 1024);
  assert.strictEqual(img.rgba.length, img.w * img.h * 4);
  assert.ok(img.rgba.some((v, i) => i % 4 === 3 && v > 200), 'some opaque pixels');
  const png = encodePng(img.w, img.h, img.rgba);
  assert.deepStrictEqual([...png.subarray(0, 4)], [0x89, 0x50, 0x4e, 0x47]);
});

test('txtr rgba8 small', (t) => {
  const file = path.join(loadConfig().gamePath, 'rom/graphics/ui/map/map_solid_line_d.txtr');
  if (!fs.existsSync(file)) return t.skip('no game files');
  const img = readTxtr(fs.readFileSync(file));
  assert.strictEqual(img.w, 64);
  assert.strictEqual(img.rgba.length, 64 * 64 * 4);
});

test('txtr bad size throws', () => {
  assert.throws(() => readTxtr(Buffer.from('TXTR\x03\x00\x00\x00\x02\x00\x00\x00\x00\x40\x00\x40\x00\x01')));
});

test('mod tiles override base', () => {
  const m = mergeSources([{ name: 'a', source: 'base' }, { name: 'a', source: 'mod:x' }, { name: 'b', source: 'base' }]);
  assert.strictEqual(m.get('a').source, 'mod:x');
  assert.strictEqual(m.size, 2);
});
