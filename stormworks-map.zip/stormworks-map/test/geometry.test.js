const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { parseGeometry } = require('../tools/lib/geometry');
const { loadConfig } = require('../server/config');

const tilesDir = path.join(loadConfig().gamePath, 'rom', 'data', 'tiles');
const tile = (name) => path.join(tilesDir, `${name}_map_geometry.bin`);

function readOrSkip(t, file) {
  if (!fs.existsSync(file)) { t.skip(`missing ${file}`); return null; }
  return fs.readFileSync(file);
}

test('arctic_tile_11 has 11 meshes + extra', (t) => {
  const buf = readOrSkip(t, tile('arctic_tile_11'));
  if (!buf) return;
  const g = parseGeometry(buf);
  assert.strictEqual(g.meshes.length, 11);
  assert.strictEqual(g.meshes[0].verts.length, 296 * 2);
  assert.strictEqual(g.meshes[0].indices.length, 840);
  assert.ok(g.extra && Array.isArray(g.extra.lines));
  assert.strictEqual(g.extra.lines[0].length, (1148 / 4) * 4);
  // first coast segment starts at the first vertex of mesh 0
  assert.ok(Math.abs(g.extra.lines[0][0] - g.meshes[0].verts[0]) < 0.01);
  assert.ok(Math.abs(g.extra.lines[0][1] - g.meshes[0].verts[1]) < 0.01);
});

test('indices in range', (t) => {
  const buf = readOrSkip(t, tile('arid_island_8_13'));
  if (!buf) return;
  for (const m of parseGeometry(buf).meshes) {
    const max = m.indices.reduce((a, b) => Math.max(a, b), -1);
    assert.ok(max < m.verts.length / 2);
  }
});

test('verts inside tile', (t) => {
  const buf = readOrSkip(t, tile('mega_island_12_6'));
  if (!buf) return;
  for (const m of parseGeometry(buf).meshes) {
    for (const v of m.verts) assert.ok(v >= -501 && v <= 501, `vertex ${v}`);
  }
});

test('consumes whole file', (t) => {
  const buf = readOrSkip(t, tile('arctic_tile_11'));
  if (!buf) return;
  const padded = Buffer.concat([buf, Buffer.from([1])]);
  assert.throws(() => parseGeometry(padded), /geometry/);
});

test('truncated throws', (t) => {
  const buf = readOrSkip(t, tile('arctic_tile_11'));
  if (!buf) return;
  assert.throws(() => parseGeometry(buf.subarray(0, 100)));
});

test('loadConfig expands %APPDATA%', () => {
  const cfg = loadConfig();
  assert.ok(!cfg.savesPath.includes('%APPDATA%'));
  assert.strictEqual(cfg.port, 37037);
});
