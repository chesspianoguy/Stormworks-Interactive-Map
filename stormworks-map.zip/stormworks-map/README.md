# Stormworks-Interactive-Map

An offline, interactive map for Stormworks: Build and Rescue. It runs entirely on your PC, in your browser.

It shows:
- every tile, drawn from the game's own map data
- all locations, including ones from mods and addons
- players, vehicles, NPCs and fires
- mission zones and the tiles you own
- game time, weather, money and research points

The page only updates when you **refresh** it. It never sends anything to the game and never uses the internet.

Data comes from two places:
- **Your newest save.** This always works, but it's only as fresh as the last save or autosave.
- **The `sw-livemap` addon.** This is optional. It sends live positions every 5 seconds while you play.

On every refresh the map uses whichever is newer. The header shows where each piece of data came from and how old it is.

## Setup

You need [Node.js](https://nodejs.org/) 20 or newer. The commands below go in a terminal opened in this folder.

The first `npm install` is the only step that uses the internet. After it, everything runs offline.

```bash
npm install
```

```bash
npm run build-map
```

```bash
npm run vendor
```

- `build-map` reads the game's map files into `data/map/`. Rerun it after a game update or after adding mods that bring new tiles.
- `vendor` copies Leaflet (the map library) into `web/vendor/`.

If Stormworks isn't installed at `D:/SteamLibrary/steamapps/common/Stormworks`, change `gamePath` in `config.json` first.

## Run

```bash
npm start
```

Then open <http://127.0.0.1:37037/>.

## The addon (live positions)

1. Copy the `addon` folder to `%APPDATA%\Stormworks\data\missions\sw-livemap\`. You should end up with `playlist.xml` and `script.lua` inside it.
2. In Stormworks, create a world and tick **sw-livemap** in the addon list.

   Stormworks normally only lets you pick addons when a world is created. To get live data in an older save you may have to start a new world. Without the addon, that save still shows up from its save file.
3. Start `npm start` before or while you play. You need to be the host (singleplayer or hosting).

When a world loads, the addon spends about 10 seconds scanning tile positions and the addons that are loaded. After that it sends a snapshot every 5 seconds. Until that first scan has run once, the map can't place tiles and says so. The scan is saved in `data/cache/`, so it survives restarts.

### Addon settings

These sit at the top of `addon/script.lua`:

| Setting | Default | What it does |
|---|---|---|
| `PORT` | 37037 | Must match `port` in `config.json` |
| `CHUNK` | 1000 | Characters per request. Lower it if snapshots never arrive. |
| `SNAP_TICKS` | 300 | Ticks between snapshots (300 = 5 s) |
| `SCAN_PER_TICK` | 200 | Lower it if the game stutters |
| `VEH_SCAN_MAX` / `OBJ_SCAN_MAX` | 4000 / 8000 | Highest vehicle and object ids scanned |
| `TILE_RANGE` | 130 | Tile scan covers ±130 km |

## Development

```bash
npm test
```

```bash
npm run fake-addon
```

- `npm test` runs all the tests. The addon's Lua runs in fengari against a fake game API.
- `npm run fake-addon` sends recorded addon data to a running server, so you can work on the page without the game.

- Design: `docs/specs/2026-10-24-stormworks-map-design.md`
- Plan: `docs/plans/2026-10-24-stormworks-map.md`
