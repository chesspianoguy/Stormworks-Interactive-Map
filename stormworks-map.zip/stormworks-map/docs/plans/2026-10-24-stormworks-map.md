# Stormworks Map Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** An offline browser map of the Stormworks world that looks like the in-game map. It shows all tiles and locations (mods too), players, vehicles, NPCs, fires, zones and game state. Data comes from an in-game addon plus the newest save, and only updates on page refresh.

**Architecture:**
- A one-time Node builder turns game files into JSON and PNG under `data/map/`.
- A Lua addon sends chunked JSON snapshots to a localhost Node server through `server.httpGet`.
- The server merges the last snapshot with the newest save's `scene.xml` and serves one state JSON plus the static Leaflet page.

**Tech Stack:**
- Node.js 24 (plain `http`, `node --test`)
- `fast-xml-parser`
- Leaflet 1.9.4, vendored
- Stormworks addon Lua

**Spec:** `docs/specs/2026-10-24-stormworks-map-design.md`

## Global Constraints

- Server binds `127.0.0.1` only. Default port `37037`. The addon uses the same port.
- No network at runtime. Leaflet gets copied from `node_modules` into `web/vendor/leaflet/`, and no CDN URLs appear anywhere.
- Page fetches `/api/state` once per load. No timers, polling or WebSocket.
- View only. The addon never changes game state, and the server has no route that sends commands to the game.
- Runtime deps: `fast-xml-parser` only. Dev/vendor: `leaflet@1.9.4`.
- Game path default `D:\SteamLibrary\steamapps\common\Stormworks`. Saves `%APPDATA%\Stormworks\saves`. User addons `%APPDATA%\Stormworks\data\missions`. All are set in `config.json`.
- World grid: tiles are 1000 m cells. Cell `(cx, cy)` has its center at world `(cx*1000, cy*1000)`, where save `y` = world `z`. Tile geometry is local, −500..500.
- Addon chunk size default 1000 chars. Snapshot every 5 s. Both are settings at the top of `script.lua`.
- Tests: `node --test`. Tests that need game or save files call `t.skip()` when the file is missing.

## Review Focus

- **Save mid-write:** the game is writing `scene.xml` during a refresh, so the file is half there. Expected: the last good parse is used, and `sources.save.error` says why. Task 3 test `partial file keeps last good`.
- **Addon gone for a long time:** the snapshot is hours older than the save. Expected: save values win, and the header shows the addon age. Task 5 test `stale addon loses to newer save`.
- **Odd names:** vehicle/player names with `&`, quotes, `%` or unicode. Expected: they show correctly and nothing breaks. Task 4 test `decodes percent-encoded unicode`, Task 6 Lua `json_str` escapes.
- **Modded world:** a workshop mod adds its own `*_map_geometry.bin` tiles. Expected: they draw, and the mod's version beats the base game's when the names match. Task 2 test `mod tiles override base`.
- **Huge saves:** thousands of zones and vehicles. Expected: the page stays usable. Task 7 uses canvas-rendered markers (`preferCanvas: true`), and the server caches the parse by mtime (Task 3 test `cache hit skips reparse`).

---

## File Structure

```
package.json            scripts: test, build-map, start, fake-addon, vendor
config.json             { gamePath, savesPath, userAddonsPath, port }
.gitignore              node_modules, data/map, data/cache, tools/scratch, web/vendor
tools/lib/geometry.js   parse *_map_geometry.bin
tools/lib/tile-xml.js   parse tile definition XML
tools/lib/playlist.js   parse playlist.xml locations/components
tools/lib/txtr.js       .txtr -> RGBA, RGBA -> PNG
tools/lib/xml.js        shared fast-xml-parser instance (tolerant opts)
tools/build-map.js      CLI: writes data/map/*
tools/fake-addon.js     CLI: replays test/fixtures/snapshot.json to server
server/config.js        load config.json + expand %APPDATA%
server/save-parser.js   scene.xml -> SaveState
server/snapshot.js      chunk assembler
server/merge.js         SaveState + AddonState -> State
server/index.js         http routes + static
addon/playlist.xml      addon manifest
addon/script.lua        snapshot + layout + addon scan
web/index.html, web/style.css
web/app.js              boot, fetch, layers, panel, search
web/geometry-layer.js   Leaflet canvas layer drawing tiles
web/markers.js          state -> Leaflet markers per layer
test/*.test.js, test/fixtures/
README.md               setup + enabling addon
```

---

### Task 1: Scaffold + map geometry parser

**Files:**
- Create: `package.json`, `config.json`, `.gitignore`, `tools/lib/geometry.js`, `server/config.js`
- Test: `test/geometry.test.js`

**Interfaces:**
- Produces: `parseGeometry(buf: Buffer) -> { meshes: Mesh[], extra: Extra|null }`
  - `Mesh = { verts: Float32Array /* x,z pairs */, indices: Uint16Array }`, where the array index is the layer id 0..10
  - `Extra` is block 11, decoded in step 1
- Produces: `loadConfig() -> { gamePath, savesPath, userAddonsPath, port }`, with `%APPDATA%` expanded

Known format (checked on `arctic_tile_11` and `arctic_island_survey`):

- The file is 11 blocks of `[u16 vcount][vcount × (f32 x, f32 y, f32 z)][u16 icount][icount × u16]`.
- `y` is always 0 in blocks 0–10. Empty blocks are `vcount=0, icount=0`.
- Block 11 has `u16 n` then a different record layout. Naive parsing of it reads `y` values like −102, 34.99.

- [ ] **Step 1: Decode block 11 and layer meaning.**
  - Write a throwaway script in `tools/scratch/` (git-ignored) that dumps block 11 at strides 8/12/16/20 for 3 tiles. Pick the stride where the file ends exactly.
  - Render blocks 0–10 of `arctic_tile_11` as SVG triangles, one color per block, and compare with the in-game map for that tile (land, sand, shallow-water bands).
  - Record the results as a comment block at the top of `geometry.js`:
    - the layer table: id → meaning → draw color
    - the block-11 record layout
  - If block 11 holds contour/height lines, `Extra = { lines: Float32Array /* x,z,h triples */ }`. Otherwise use whatever it decodes to.
- [ ] **Step 2: `git init`, write `package.json`.**
  - `"type": "commonjs"`
  - scripts:
    - `"test": "node --test test/"`
    - `"build-map": "node tools/build-map.js"`
    - `"start": "node server/index.js"`
    - `"fake-addon": "node tools/fake-addon.js"`
    - `"vendor": "node tools/vendor.js"`
  - Write `config.json` with the defaults from Global Constraints and `.gitignore`. Run `npm i fast-xml-parser leaflet@1.9.4`.
- [ ] **Step 3: Write failing tests** in `test/geometry.test.js`, using real files from `config.gamePath/rom/data/tiles/`:
  - `arctic_tile_11 has 11 meshes + extra`: `meshes.length === 11`, `meshes[0].verts.length === 296*2`, `meshes[0].indices.length === 840`
  - `indices in range`: for every mesh, `max(indices) < verts.length/2`
  - `verts inside tile`: every x,z within `[-501, 501]` for blocks 0–10
  - `consumes whole file`: the parser asserts it ends exactly at `buf.length` (throws `Error('geometry: trailing bytes')` otherwise)
  - `truncated throws`: `parseGeometry(buf.subarray(0, 100))` throws
- [ ] **Step 4:** Run `npm test`. Expected: FAIL, `parseGeometry is not a function`.
- [ ] **Step 5:** Implement `parseGeometry` (drop `y` from the stored verts) and `loadConfig`.
- [ ] **Step 6:** Run `npm test`. Expected: PASS. Also run it over all 1812 files in a quick loop and expect 0 throws.
- [ ] **Step 7:** Commit `feat: map geometry parser`.

### Task 2: Map builder (tiles, playlists, icons, mods)

**Files:**
- Create: `tools/lib/xml.js`, `tools/lib/tile-xml.js`, `tools/lib/playlist.js`, `tools/lib/txtr.js`, `tools/build-map.js`, `tools/vendor.js`
- Test: `test/build.test.js`, `test/fixtures/playlist-mini.xml`, `test/fixtures/tile-mini.xml`

**Interfaces:**
- Consumes: `parseGeometry`, `loadConfig` (Task 1)
- Produces: `xmlParser` from `tools/lib/xml.js`
  - fast-xml-parser options: `ignoreAttributes:false`, `attributeNamePrefix:''`, `allowBooleanAttributes:true`, `parseAttributeValue:false`, and `isArray` for repeated tags
  - The numeric attribute names (`30="1000"`) make the XML invalid for strict parsers. fast-xml-parser without `validate` accepts them, and the tile test asserts that.
- Produces: `readTileXml(text) -> { isIsland, purchasable, cost }`
- Produces: `readPlaylist(text, source) -> Location[]`
  - `Location = { source, name, tile, components: [{ name, type, tags, x, y, z }] }`, where x/y/z are tile-local, read from `transform` attrs 30/31/32
- Produces: `readTxtr(buf) -> { w, h, rgba }`, `encodePng(w, h, rgba) -> Buffer` (zlib from `node:zlib`, CRC32 written inline)
- Produces, on disk:
  - `data/map/tiles/<name>.json` = `{ meshes: [{v:[...], i:[...]}], extra }`, with numbers rounded to 0.1
  - `data/map/tiles.json` = `{ <name>: { isIsland, purchasable, cost, source } }`
  - `data/map/locations.json` = `Location[]`
  - `data/map/icons.png`, `data/map/icons.json` (`{ <iconName>: [x,y,w,h] }`, from `atlas_mapicons.xml`)
- `tools/vendor.js` copies `node_modules/leaflet/dist/{leaflet.js,leaflet.css,images/}` into `web/vendor/leaflet/`.

Sources, in this order (a later source beats an earlier one when tile names match):

1. `gamePath/rom/data/tiles`
2. each `mod_path` from the newest save's `active_mods`, plus each folder in `%APPDATA%\Stormworks\data\mods`. Scan `<mod>/**/data/tiles` and `<mod>/**/missions/*/playlist.xml`.

Playlists come from `rom/data/missions/*/playlist.xml`, `userAddonsPath/*/playlist.xml` and the mod folders. `source` is `"base"`, `"user:<folder>"` or `"mod:<folder>"`. The newest save's `active_mods` is read with a regex on `<mod_path value="...">`, so the builder doesn't depend on the Task 3 parser.

- [ ] **Step 1: Write failing tests**
  - `tile xml with numeric attrs parses`: `readTileXml(fixture)` → `{ isIsland:true, purchasable:true, cost:200000 }`
  - `playlist locations`: fixture with 1 location / 2 components gives `.length===1`, `components[1].x === 64.4` (from `30="64.402916"`, rounded 0.1), `tile === "data/tiles/island_33_tile_32.xml"` normalized to `"island_33_tile_32"`
  - `txtr round trip`: `readTxtr` on the real `atlas_mapicons.txtr` gives `w*h*4 === rgba.length`, and `encodePng` output starts with `89 50 4E 47`
  - `mod tiles override base`: the build's merge function `mergeSources([{name:'a',source:'base'},{name:'a',source:'mod:x'}])` keeps `source==='mod:x'`. Export `mergeSources(list) -> Map`.
- [ ] **Step 2:** Run `npm test`. Expected: FAIL.
- [ ] **Step 3:** Implement the libs. For `.txtr`: the header is 25 bytes for 512×512 RGBA (1048601 = 1048576+25). Find the w/h fields in the header and assert `25 + w*h*4 === buf.length`. Throw on any other size.
- [ ] **Step 4:** Implement `build-map.js`. It logs counts (`tiles: N, locations: N, mods: N`) and exits with code 1 if `gamePath` is missing.
- [ ] **Step 5:** Run `npm test`, then `npm run build-map && npm run vendor`. Expected: PASS, and `data/map/tiles.json` has ≥ 1800 entries.
- [ ] **Step 6:** Commit `feat: map builder`.

### Task 3: Save parser

**Files:**
- Create: `server/save-parser.js`
- Test: `test/save-parser.test.js`, `test/fixtures/scene-mini.xml` (hand-cut from the real autosave: game_data, 2 vehicles, 3 objects, 2 zones, purchased_tiles)

**Interfaces:**
- Consumes: `xmlParser` (Task 2)
- Produces: `parseSave(text: string) -> SaveState`
- Produces: `loadSave(dir: string) -> { state: SaveState, mtime, name, error? }`, cached by `scene.xml` mtime per dir
- Produces: `listSaves(savesPath) -> [{ name, mtime }]`, newest first, only dirs containing `scene.xml`

`SaveState` fields and where each comes from in `scene.xml`:

- `game = { day, month, year, dayTick, money, weather }` from `game_data` attrs (`day_tick`, `currency`, `weather`)
- `player = { x, y, z }` from `game_data/player_pos`
- `playlists: string[]` from `active_playlists/playlist_name@value`
- `mods: string[]` from `active_mods/mod_path@value`
- `purchasedTiles: [{cx, cy}]` and `discoveredTiles` from `tiles/purchased_tiles` and `tiles/discovered_tiles` (`value@x,y`)
- `vehicles: [{ id, groupId, x, y, z, isMission, isStatic, tags }]` from `vehicles/vehicle`, position from `transform` 30/31/32 (a missing attr = 0)
- `characters: [{ id, type, steamId, x, y, z }]` from `object` elements, all types kept with their numeric `type`
- `zones: [{ id, name, tags, x, y, z, radius }]` from `cargo/zone` (`unique_id`, `display_name`, `tags`, `transform`)
- `fires` from `missions_global/tracked_fires` children
- `addonNodes` from `game_data/addon_nodes/node` (`pos@x,y`, tags)

- [ ] **Step 1: Write failing tests**
  - `parses mini scene`: `player.x === -20041.557097`, `vehicles.length === 2`, `vehicles[0].tags === 'lift_airstrip'`, `zones[0].name === 'Coastguard Outpost Beginner'`, `purchasedTiles` deep-equals `[{cx:-20, cy:-5}]`, `playlists.includes('rom/data/missions/default_ai')`
  - `real autosave`: (skip if missing) `vehicles.length > 0`, `zones.length > 1000`, parse < 3000 ms
  - `partial file keeps last good`: write the fixture to a temp dir, `loadSave` → ok, then overwrite it with the first half of the file and bump the mtime, `loadSave` → same `state`, `error` is set
  - `cache hit skips reparse`: two `loadSave` calls without an mtime change return the same object reference
- [ ] **Step 2:** Run `npm test`. Expected: FAIL.
- [ ] **Step 3:** Implement. A missing section gives an empty array, never a throw. A throw from the XML parser gets caught in `loadSave`.
- [ ] **Step 4:** Run `npm test`. Expected: PASS.
- [ ] **Step 5:** Commit `feat: save parser`.

### Task 4: Snapshot assembler

**Files:**
- Create: `server/snapshot.js`
- Test: `test/snapshot.test.js`

**Interfaces:**
- Produces: `createAssembler({ onComplete(kind, obj, receivedAt), log }) -> { handle(pathname, query) -> boolean }`
  - routes: `begin` (`s`, `n`), `part` (`s`, `i`, `d`), `end` (`s`)
  - The data `d` is percent-encoded, with `decodeURIComponent` applied per chunk *after* joining. The Lua side encodes the whole JSON and then splits it, so a chunk boundary can fall inside a `%XX`.
  - On `end` with all `n` parts, it runs `JSON.parse` on the joined string and calls `onComplete(obj.kind, obj, Date.now())`.
  - Pending snapshots older than 60 s get dropped. A duplicate part overwrites. An unknown `s` on `part`/`end` is ignored and logged.

- [ ] **Step 1: Write failing tests**
  - `in order`
  - `out of order`
  - `missing chunk never completes`: `onComplete` not called
  - `duplicate chunk`: completes once with the right data
  - `split inside escape`: `'%C3%A9'` split as `'%C'` + `'3%A9'` decodes to `'é'`
  - `decodes percent-encoded unicode`: name `"Bob & \"Ann\" 100% 🚁"` survives the round trip
  - `bad json logged not thrown`
- [ ] **Step 2:** Run `npm test`. Expected: FAIL.
- [ ] **Step 3:** Implement.
- [ ] **Step 4:** Run `npm test`. Expected: PASS.
- [ ] **Step 5:** Commit `feat: snapshot assembler`.

### Task 5: Merge + HTTP server + fake addon

**Files:**
- Create: `server/merge.js`, `server/index.js`, `tools/fake-addon.js`, `test/fixtures/snapshot.json`, `test/fixtures/layout.json`, `test/fixtures/addons.json`
- Test: `test/merge.test.js`, `test/server.test.js`

**Interfaces:**
- Consumes: `loadSave`, `listSaves` (Task 3), `createAssembler` (Task 4), `loadConfig` (Task 1)
- Addon message kinds, which are also the fixture shapes and what Task 6 must emit:
  - `snap`: `{ kind:"snap", game:{hour,minute,day,month,year,money,research,weather:{fog,rain,wind,temp}}, players:[{peer,name,steam,x,y,z,heading,vehicle}], vehicles:[{id,name,peer,x,y,z,mass,voxels,loaded}], chars:[{id,name,type,x,y,z,dead}], fires:[{id,x,y,z,lit}] }`
  - `layout`: `{ kind:"layout", tiles:[{cx,cy,name,purchased,cost}] }`
  - `addons`: `{ kind:"addons", addons:[{index,name,locations:[{name,tile,components:[{name,type,tags,x,y,z}]}]}] }`, with x/y/z already in world coordinates
- Produces: `merge({ save, saveTime, snap, snapTime, layout, addons }) -> State`. This is the spec's `/api/state` shape. Rules:
  - Each of `players`, `vehicles`, `characters`, `fires`, `game` comes from the addon when `snapTime > saveTime`, otherwise from the save. Each section is tagged `{ source, time, items }`.
  - The addon's `snap.chars` maps to `characters`.
  - From the save, `players` = one entry `{ name:'player', ...save.player }`.
  - `zones` and `purchasedTiles` always come from the save.
  - `tilesLayout` = `layout.tiles` if present, else `null` (the page then shows a "run game with addon once" hint).
  - `addons` from the addon message, plus the builder's `locations.json` served separately.
- Produces: `startServer(cfg) -> Promise<http.Server>`. It persists `layout` and `addons` to `data/cache/{layout,addons}.json` and loads them at start.
  - routes: `/sw/*`, `GET /api/state[?save=name]`, `GET /api/saves`, and static files from `web/` at `/` and `data/map/` at `/map/`
  - responses for those routes:
    - static path traversal (`..`) → 403
    - unknown route → 404
    - `/sw/*` always 200 with body `ok`
  - If `data/map/tiles.json` is missing, it logs `run: npm run build-map` and still starts.
  - `addons` / `layout` sent by the addon get re-requested only when missing: the `/sw/end` response body is `need:layout,addons` when either is missing, otherwise `ok`. The addon reads the httpGet reply in `httpReply`.
- `fake-addon.js [--port N]` sends `layout`, `addons`, then `snap` from the fixtures, using the same chunk protocol with chunk size 1000.

- [ ] **Step 1: Write failing tests**
  - `addon newer wins`: `snapTime = saveTime + 1` gives `vehicles.source === 'addon'`
  - `stale addon loses to newer save`: `snapTime = saveTime - 3600e3` gives `vehicles.source === 'save'`, and `sources.addon.time` is still reported
  - `no addon at all`: `snap = null` gives every section from `'save'`, `tilesLayout === null`
  - `no save at all`: `save = null`, `snap` present, gives sections from `'addon'`, `zones.items` is `[]`
  - server tests on port 0:
    - `GET /api/state` returns 200 JSON with keys `generated, sources, game, players, vehicles, characters, fires, zones, tilesLayout`
    - `GET /../config.json` → 403
    - running `fake-addon` against the server gives `/api/state` `.vehicles.source==='addon'`
    - `/sw/end` replies `need:layout,addons` before layout is sent and `ok` after
    - `listen address is 127.0.0.1`
- [ ] **Step 2:** Run `npm test`. Expected: FAIL.
- [ ] **Step 3:** Implement `merge`, `startServer`, `fake-addon`. `index.js` calls `startServer(loadConfig())` when run directly.
- [ ] **Step 4:** Run `npm test`. Expected: PASS.
- [ ] **Step 5:** Commit `feat: server and merge`.

### Task 6: Stormworks addon

**Files:**
- Create: `addon/playlist.xml`, `addon/script.lua`, `README.md` (install + enable section)
- Test: manual (Task 8). Lua is checked by reading it against the shapes in the Task 5 Interfaces.

**Interfaces:**
- Consumes: the chunk protocol (Task 4) and the message shapes (Task 5)
- Settings at the top of `script.lua`: `PORT=37037`, `CHUNK=1000`, `SNAP_TICKS=300` (5 s at 60 tps), `SCAN_PER_TICK=200`, `ID_SCAN_MAX=4000`, `TILE_RANGE=130` (cells, ±)

Behavior:

- **Callbacks:**
  - `onCreate(is_world_create)`: reset state and queue `layout` and `addons` jobs.
  - `onTick`: run at most one job step, then flush up to 4 queued httpGets.
  - `httpReply(port, request, reply)`: if the reply contains `need:layout` / `need:addons`, re-queue those jobs.
- **Jobs (step-wise state machines, so no tick does more than `SCAN_PER_TICK` API calls):**
  - `layout`: for `cx, cy` in `-TILE_RANGE..TILE_RANGE`, take `server.getTile(matrix.translation(cx*1000, 0, cy*1000))`. When it succeeds with a non-empty `name`, record `{cx, cy, name, purchased, cost}`.
  - `addons`: for each addon `0..server.getAddonCount()-1`:
    - `getAddonData`
    - each location: `getLocationData`. Find the tile's world origin with `server.getTileTransform(matrix.translation(0,0,0), loc.tile, 200000)`. If that fails, emit the location with `x=nil`.
    - each component: `getLocationComponentData`. World pos = tile origin × component `transform`, using `matrix.multiply`, then `matrix.position`.
  - `snap`, every `SNAP_TICKS`:
    - players via `server.getPlayers`, `getPlayerPos`, `getPlayerCharacterID` + `getCharacterVehicle`. Heading = `atan2` of the matrix forward x/z.
    - vehicles: ids `1..ID_SCAN_MAX` with `server.getVehiclePos(id)` success, plus `getVehicleData(id)` (`name`, `mass`, `voxels`, `simulating`). This is spread across ticks, and the snap is sent once the scan finishes.
    - chars: ids `1..ID_SCAN_MAX` with `server.getObjectData(id)` (`object_type`, `name`, `dead`) and `server.getObjectPos`
    - fires: tracked from `onFireExtinguished`/object data where `object_type` is fire. Mark it `-- best effort` in a comment.
    - game: `server.getTime`, `server.getDate`, `server.getCurrency`, `server.getResearchPoints`, `server.getWeather(player matrix)`
- **Helpers:** `json_str(s)` escapes `\ " \n \r \t` and control chars as `\u00XX`. `json(v)` writes tables (array when `#t>0` or empty with `__array` marker), numbers (`%.2f`, integers plain) and booleans. `send(kind_tbl)` runs `url_encode(json(...))` (encodes everything except `A-Za-z0-9-_.~`), splits it into `CHUNK` pieces and queues `begin/part/end`.
- **API names:** check every `server.*` call against the in-game Lua docs (the addon editor's API list, the `?` in the addon editor). Any call that doesn't exist gets dropped, with a `-- not available:` comment.

- [ ] **Step 1:** Write `playlist.xml`: name `sw-livemap`, no locations. Use the same root shape as `%APPDATA%\Stormworks\data\mods\...\playlist.xml` in the user's existing mod.
- [ ] **Step 2:** Write `script.lua` per above.
- [ ] **Step 3:** Desk-check the output shape. Write `tools/scratch/lua-shape.md` with one hand-traced `json()` output for a `snap` with 1 player / 1 vehicle, and confirm it matches the `snap` shape in the Task 5 Interfaces key-for-key.
- [ ] **Step 4:** README: copy `addon/` to `%APPDATA%\Stormworks\data\missions\sw-livemap\`, then enable it.
  - Research step: confirm in game whether an addon can be enabled on an existing save (world settings/addon menu). Document what works, and if it can't be, say that it needs a new world.
- [ ] **Step 5:** Commit `feat: stormworks addon`.

### Task 7: Map page

**Files:**
- Create: `web/index.html`, `web/style.css`, `web/app.js`, `web/geometry-layer.js`, `web/markers.js`
- Test: `test/web.test.js` (pure functions only), plus a manual browser check against `fake-addon`

**Interfaces:**
- Consumes: `/api/state` (Task 5), `/map/tiles.json`, `/map/tiles/<name>.json`, `/map/locations.json`, `/map/icons.{png,json}` (Task 2), and `web/vendor/leaflet/`
- Produces, in `web/markers.js` (ES module, pure, also imported by the test):
  - `worldToLatLng(x, z) -> [lat, lng]` = `[z, x]` (north up = +z)
  - `tileOrigin(cx, cy) -> {x: cx*1000, z: cy*1000}`
  - `buildLayers(state, locations) -> { [layerId]: Array<{ latlng, icon, title, info }> }`
    - layer ids: `tiles`, `locBase`, `locMods`, `zones`, `players`, `vehicles`, `npcs`, `fires`, `owned`
  - `search(index, q) -> results[]` (case-insensitive substring over titles, max 50)
- Produces, in `web/geometry-layer.js`: `GeometryLayer` (extends `L.GridLayer`, canvas)
  - `createTile` draws every map tile intersecting it from cached `/map/tiles/<name>.json`, using `tilesLayout` for placement
  - fill order: water background, then mesh layers in the order from Task 1's layer table, then `extra` lines
  - colors from that table

Page behavior:

- `L.map` with `crs: L.CRS.Simple`, `preferCanvas: true`, zoom range −6..3.
- On load it fetches state and locations once. There's no other fetch except lazy tile JSON.
- **Header:** source badges (`addon • 12 s old`, `save "autosave" • 3 min old`), the game date/time/weather, and a save picker (from `/api/saves`, which reloads with `?save=`). It shows `addon not connected` when `sources.addon` is null, and `run game with addon once to place tiles` when `tilesLayout` is null.
- A layer control with all 9 layer ids. `locMods` is grouped by `source`.
- Clicking a marker opens a side panel showing every key/value of `info`.
- A search box that pans to the result and opens its panel.
- Icons are a CSS sprite from `icons.png` + `icons.json`, with a fallback dot when an icon name is missing.

- [ ] **Step 1: Write failing tests** in `test/web.test.js` (dynamic `import()` of `web/markers.js`)
  - `worldToLatLng(100, -200)` deep-equals `[-200, 100]`
  - `buildLayers(fixtureState, fixtureLocations)` gives `vehicles.length` matching the fixture, `players[0].title === fixture name`, `locMods` entries carrying `info.source` starting `mod:` or `user:`
  - `search` of `'coast'` finds the `Coastguard` zone
  - a location with `x === null` is skipped, not placed at 0,0
- [ ] **Step 2:** Run `npm test`. Expected: FAIL.
- [ ] **Step 3:** Implement `markers.js`, then the layer, page and CSS.
- [ ] **Step 4:** Run `npm test`. Expected: PASS.
- [ ] **Step 5: Manual check.** Run `npm start`, run `npm run fake-addon` in another terminal, and open `http://127.0.0.1:37037/`.
  - The map draws tiles and the fixture markers appear.
  - With the network disabled (DevTools offline), a reload still works.
  - The page makes no requests after it loads (DevTools Network stays still for 30 s).
- [ ] **Step 6:** Commit `feat: map page`.

### Task 8: In-game check + tune

**Files:**
- Modify: `addon/script.lua` (settings only), `README.md`

- [ ] **Step 1:** Install the addon per the README, then run `npm start` and Stormworks.
- [ ] **Step 2: Chunk size.** Raise `CHUNK` until the server logs a decode failure or parts go missing, then set it to half of the last size that worked. Record the value in the README.
- [ ] **Step 3: Check against the game.**
  - Player marker within ~5 m of the in-game map position.
  - Vehicle count matches the in-game vehicle list.
  - Purchased tile shaded.
  - At least one mod location shown, if a mod with locations is active.
- [ ] **Step 4:** Check the frame rate with the addon on vs off (no visible hitch). If there's a hitch, lower `SCAN_PER_TICK`.
- [ ] **Step 5:** Commit `chore: tune addon settings from in-game test`.
