# Stormworks Map — Design

Date: 2026-10-24
Status: draft for review

## Goal

A map of the Stormworks world in the browser that looks like the in-game map and shows:

- all tiles and locations, including locations added by mods/addons
- the player, other players, AI/NPC characters and all vehicles
- mission zones and other mission data
- other game state the game exposes (time, weather, money, fires)

## Constraints (from user)

- Same PC only. Game and map run on this machine.
- Runs entirely offline. No internet at runtime. All libraries live on disk.
- Page does not update by itself. Data only updates when the page is refreshed.
- View only. The map never changes the game.
- Data comes from two sources: a small in-game addon and the save files.

## Environment (checked)

- Game: `D:\SteamLibrary\steamapps\common\Stormworks`
- Game map data: `rom/data/tiles/*_map_geometry.bin` (1812 files), tile XMLs `rom/data/tiles/*.xml`
- Built-in addons/playlists: `rom/data/missions/*`
- Map icons: `rom/graphics/ui/map/atlas_mapicons.txtr` + `.xml`
- User data: `%APPDATA%\Stormworks\data\missions` (user addons), `data\mods`
- Saves: `%APPDATA%\Stormworks\saves\<name>\scene.xml` (+ `vehicles/`, `tiles/`, `script_data/`)
- Node.js v24.22.1, npm 11.19.1

## Architecture

```
 Stormworks (game)                      This PC
 ┌────────────────────┐   httpGet     ┌─────────────────────────┐   GET on refresh  ┌──────────┐
 │ sw-livemap addon   │ ────────────> │ map server (Node)       │ <──────────────── │ browser  │
 │ (Lua)              │  localhost    │  - holds last snapshot  │ ────────────────> │ map page │
 └────────────────────┘               │  - reads newest save    │   JSON + files    └──────────┘
                                      │  - serves static files  │
 save files (scene.xml) ────────────> └─────────────────────────┘
 game files (rom/)  ──> map builder (run once) ──> data/map/*.json, icons PNG
```

Four parts, each with one job:

1. **Map builder** (`tools/build-map.js`, run once and after game updates)
2. **Addon** (`addon/script.lua` + `playlist.xml`)
3. **Map server** (`server/`)
4. **Map page** (`web/`)

## 1. Map builder

Input: the game's install folder. Output: files in `data/map/`.

- **Tile geometry.** It parses each `*_map_geometry.bin` into land/height polygons and contour lines. Output is one compact JSON file per tile, in tile-local coordinates. The first look at the format shows a uint16 count, then `(x, height, z)` float32 points, starting with the sea-level (height 0) line. The full layout (the later sections, the index lists) gets confirmed in the first plan task using a few known tiles.
- **Tile info.** From the tile XMLs it reads the name, island flag, purchasable flag and cost.
- **Base locations.** From `rom/data/missions/*/playlist.xml` it reads each location, the tile it's on, its components and its zones.
- **User addons.** It reads `%APPDATA%\Stormworks\data\missions\*/playlist.xml` the same way, tagged with the addon name.
- **Icons.** It converts `atlas_mapicons.txtr` to PNG and the atlas XML to JSON (icon name → rect).
- **Style.** The colors come from the game's map shader (`map_environment.glslf`) and are hard-coded in the page. They're not parsed at runtime.

Tile world placement (where each tile sits in the world) is not in the tile XMLs. Sources, in order:

1. a game file with the layout, if one is found during the plan's research task
2. the addon's one-time tile scan (see below), saved to `data/map/tile-layout.json`

## 2. Addon (`sw-livemap`)

Lua addon. It talks only to `localhost` through `server.httpGet(port, path)`. Port is 37037 (a setting at the top of the script).

**One-time on world load** (then cached by the server, re-sent only when the server asks):

- **Tile layout scan.** It calls `server.getTile(matrix)` on a 1000 m grid across the world and records the tile name, origin and purchase state. The scan is spread over many ticks so it doesn't lag.
- **Loaded addons.** `server.getAddonCount`, `getAddonData`, `getLocationData`, `getLocationComponentData` give every loaded addon's locations, zones and spawn points. This covers mod addons that the map builder can't see.

**Snapshot, every 5 s** (setting):

- players: name, steam id, position, heading, seated vehicle
- vehicles: id, name, owner peer, position, mass, voxel count, loaded or not. Found by scanning vehicle ids, so vehicles from before the addon loaded are included.
- characters/NPCs/creatures: id, name, position, dead or alive. Found by scanning object ids.
- fires: position, lit or not
- game: time of day, date, weather at the player, money, research points

**Transport.** One snapshot is split into chunks of at most 1000 chars (setting):

- `GET /sw/begin?s=<snap>&n=<chunks>`
- `GET /sw/part?s=<snap>&i=<k>&d=<url-encoded data>`
- `GET /sw/end?s=<snap>`

The data is a compact JSON-like string built in Lua. The server only accepts a snapshot when all chunks have arrived. An incomplete snapshot is dropped, and the last good one stays.

**Limit.** The addon can't read which default missions are active. The default mission addon keeps that state inside itself. The map shows mission *zones* and *locations*, plus whatever the save file holds.

## 3. Map server (Node)

- Plain Node `http` module. No framework.
- Listens on `127.0.0.1` only. It never binds to other interfaces.
- Deps are installed once with npm and then used offline: `fast-xml-parser` (save reading) and `leaflet` (copied into `web/vendor/`).

**Routes:**

| Route | Does |
|---|---|
| `/sw/*` | gets chunks from the addon |
| `GET /api/state` | gives one merged state JSON (see below) |
| `GET /api/saves` | lists save folders with their modified times |
| `/` and static | `web/` and `data/map/` |

**`/api/state`** works like this:

1. It finds the newest save folder (or the one picked with `?save=<name>`).
2. It parses `scene.xml`: player position, game data, active playlists, vehicles with transforms, objects (characters), zones.
3. It takes the last addon snapshot, if there is one.
4. It merges them by field: an addon value beats a save value when the addon snapshot is newer than the save file. Each section is marked with `source: "addon" | "save"` and a time.
5. It returns `{ generated, sources: {addon:{time}, save:{name,time}}, game, players, vehicles, characters, fires, zones, locations, addons, tiles }`.

Save parsing is tolerant: the .NET XML parser rejected `scene.xml`, so the parser must handle what the game writes. The parsed save is cached by file mtime, so a refresh doesn't re-parse a 7.8 MB file when nothing has changed.

The addon's tile layout and addon list get written to `data/cache/` so they survive restarts.

## 4. Map page

- Leaflet with `CRS.Simple`. World meters map straight to map units, north up.
- A custom canvas layer draws the tile geometry from `data/map/` in the in-game map style: water, land height bands, contours.
- It fetches `/api/state` once when the page loads. There's no timer, no WebSocket, no polling.

**Layers** (toggle each):

- tiles + names
- base locations
- mod/addon locations (grouped by addon)
- mission zones
- players
- vehicles
- NPCs
- fires
- purchased / for-sale tiles

**Other features:**

- Click a marker for an info panel with all its fields.
- Search by name across all layers.
- Header: data source (addon or save), how old the data is, save name, a save picker, and game time and weather.
- Markers use the game's map icons.

## Error handling

- **No addon data:** the page shows save data only, with the badge "addon not connected".
- **No save found:** the page shows the map and addon data only. If neither exists, the page says so.
- **A bad chunk or snapshot** gets dropped and logged. The last good one stays.
- **A save that won't parse:** the page shows the error in its header and uses the last good parse.
- **Missing map build:** the server tells you at startup to run `npm run build-map`.

## Testing

- Map builder: unit tests on a few real `.bin` files with known checks (point counts, bounds in the tile's 1000 m square).
- Save parser: a test on a copy of a real `scene.xml` (player position, vehicle count, playlists).
- Snapshot assembly: tests for in-order, out-of-order, missing-chunk and duplicate-chunk cases.
- A fake-addon script that sends a recorded snapshot to the server, so the page can be checked without the game.
- One manual check in the game with the addon enabled.

Test runner: Node's built-in `node --test`.

## Risks / open items

- **`.bin` format:** only the first section has been checked. The plan starts with a research task to decode it fully before anything is built on it.
- **Adding the addon to a save:** Stormworks addons are normally picked when a world is created. The plan has to confirm how to enable the addon on an existing save, or document that it needs a new save.
- **`httpGet` path length limit:** unknown. The chunk size is a setting, and the first in-game test sets it.
- **Id scans:** scanning vehicle and object ids costs time per tick. The scan is spread out and capped, with settings to tune it.

## Out of scope

- Sharing the map with other PCs or over the internet
- Live auto-updating page
- Any control of the game from the map
- 3D terrain rendering from `.mesh` files

## Project layout

```
stormworks-map/
  addon/            playlist.xml, script.lua
  tools/            build-map.js, fake-addon.js, lib/
  server/           index.js, save-parser.js, snapshot.js, merge.js
  web/              index.html, app.js, style.css, vendor/leaflet/
  data/map/         builder output (git-ignored)
  data/cache/       addon tile layout + addon list (git-ignored)
  test/
  config.json       game path, port, save folder
  package.json
```
