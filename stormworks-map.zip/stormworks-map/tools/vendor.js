// Copies Leaflet into web/vendor so the page never needs the network.
const fs = require('node:fs');
const path = require('node:path');
const { ROOT } = require('../server/config');

const src = path.join(ROOT, 'node_modules', 'leaflet', 'dist');
const dst = path.join(ROOT, 'web', 'vendor', 'leaflet');
fs.mkdirSync(dst, { recursive: true });
for (const f of ['leaflet.js', 'leaflet.css']) fs.copyFileSync(path.join(src, f), path.join(dst, f));
fs.cpSync(path.join(src, 'images'), path.join(dst, 'images'), { recursive: true });
console.log(`leaflet copied to ${path.relative(ROOT, dst)}`);
