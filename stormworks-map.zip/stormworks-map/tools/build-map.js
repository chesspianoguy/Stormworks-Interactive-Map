// Builds data/map/* from the game install (+ mods and user addons). Rerun after game updates.
const fs = require('node:fs');
const path = require('node:path');
const { loadConfig, ROOT } = require('../server/config');
const { parseGeometry } = require('./lib/geometry');
const { readTileXml } = require('./lib/tile-xml');
const { readPlaylist } = require('./lib/playlist');
const { readTxtr, encodePng } = require('./lib/txtr');
const { xmlParser } = require('./lib/xml');

const OUT = path.join(ROOT, 'data', 'map');

// Later entries win on equal name (mods override base).
function mergeSources(list) {
  const m = new Map();
  for (const item of list) m.set(item.name, item);
  return m;
}

const r1 = (n) => Math.round(n * 10) / 10;

function listDirs(dir) {
  try {
    return fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => path.join(dir, d.name));
  } catch {
    return [];
  }
}

// Find files named `name` (or dirs ending in `suffix`) up to `depth` levels below `dir`.
function findFiles(dir, test, depth = 4) {
  const out = [];
  const walk = (d, level) => {
    let entries;
    try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (level < depth) walk(p, level + 1); } else if (test(p)) out.push(p);
    }
  };
  walk(dir, 0);
  return out;
}

function newestSaveMods(savesPath) {
  const saves = listDirs(savesPath)
    .map((d) => ({ d, f: path.join(d, 'scene.xml') }))
    .filter((s) => fs.existsSync(s.f))
    .sort((a, b) => fs.statSync(b.f).mtimeMs - fs.statSync(a.f).mtimeMs);
  if (!saves.length) return [];
  // Only the head of scene.xml is needed; active_mods sits in game_data near the top.
  const fd = fs.openSync(saves[0].f, 'r');
  const head = Buffer.alloc(512 * 1024);
  const n = fs.readSync(fd, head, 0, head.length, 0);
  fs.closeSync(fd);
  return [...head.toString('utf8', 0, n).matchAll(/<mod_path value="([^"]+)"/g)].map((m) => m[1]);
}

function tileSources(cfg) {
  const sources = [{ source: 'base', dir: path.join(cfg.gamePath, 'rom', 'data', 'tiles') }];
  const modDirs = [...newestSaveMods(cfg.savesPath), ...listDirs(cfg.modsPath || '')];
  for (const mod of modDirs) {
    const tag = `mod:${path.basename(mod)}`;
    for (const f of findFiles(mod, (p) => p.endsWith('_map_geometry.bin'))) {
      sources.push({ source: tag, dir: path.dirname(f) });
    }
  }
  // de-duplicate dirs (a mod dir yields one entry per file above)
  const seen = new Set();
  return { sources: sources.filter((s) => !seen.has(s.dir) && seen.add(s.dir)), modDirs };
}

function playlistFiles(cfg, modDirs) {
  const out = [];
  for (const d of listDirs(path.join(cfg.gamePath, 'rom', 'data', 'missions'))) out.push({ f: path.join(d, 'playlist.xml'), source: 'base' });
  for (const d of listDirs(cfg.userAddonsPath || '')) out.push({ f: path.join(d, 'playlist.xml'), source: `user:${path.basename(d)}` });
  for (const mod of modDirs) {
    for (const f of findFiles(mod, (p) => path.basename(p) === 'playlist.xml')) out.push({ f, source: `mod:${path.basename(mod)}` });
  }
  return out.filter((p) => fs.existsSync(p.f));
}

function buildTiles(sources) {
  const entries = [];
  for (const { source, dir } of sources) {
    let files;
    try { files = fs.readdirSync(dir); } catch { continue; }
    for (const f of files.filter((x) => x.endsWith('_map_geometry.bin'))) {
      const name = f.replace(/_map_geometry\.bin$/, '');
      entries.push({ name, source, bin: path.join(dir, f), xml: path.join(dir, `${name}.xml`) });
    }
  }
  const merged = mergeSources(entries);
  fs.mkdirSync(path.join(OUT, 'tiles'), { recursive: true });
  const index = {};
  let failed = 0;
  for (const t of merged.values()) {
    try {
      const g = parseGeometry(fs.readFileSync(t.bin));
      const json = {
        meshes: g.meshes.map((m) => ({ v: Array.from(m.verts, r1), i: Array.from(m.indices) })),
        lines: g.extra.lines.map((l) => Array.from(l, r1)),
      };
      fs.writeFileSync(path.join(OUT, 'tiles', `${t.name}.json`), JSON.stringify(json));
      const info = fs.existsSync(t.xml) ? readTileXml(fs.readFileSync(t.xml, 'utf8')) : { isIsland: false, purchasable: false, cost: 0 };
      index[t.name] = { ...info, source: t.source };
    } catch (e) {
      failed++;
      console.warn(`skip tile ${t.name} (${t.source}): ${e.message}`);
    }
  }
  fs.writeFileSync(path.join(OUT, 'tiles.json'), JSON.stringify(index));
  return { count: Object.keys(index).length, failed };
}

function buildLocations(files) {
  const all = [];
  for (const { f, source } of files) {
    try {
      all.push(...readPlaylist(fs.readFileSync(f, 'utf8'), source));
    } catch (e) {
      console.warn(`skip playlist ${f}: ${e.message}`);
    }
  }
  fs.writeFileSync(path.join(OUT, 'locations.json'), JSON.stringify(all));
  return all.length;
}

function buildIcons(gamePath) {
  const dir = path.join(gamePath, 'rom', 'graphics', 'ui', 'map');
  const img = readTxtr(fs.readFileSync(path.join(dir, 'atlas_mapicons.txtr')));
  fs.writeFileSync(path.join(OUT, 'icons.png'), encodePng(img.w, img.h, img.rgba));
  const atlas = xmlParser.parse(fs.readFileSync(path.join(dir, 'atlas_mapicons.xml'), 'utf8')).atlas;
  const icons = {};
  for (const r of atlas.regions.region) {
    // l/r/b/t are normalized texture coords; b < t, rows stored in v order.
    const x = Math.round(parseFloat(r.l) * img.w);
    const y = Math.round(parseFloat(r.b) * img.h);
    icons[r.name] = [x, y, Math.round(parseFloat(r.r) * img.w) - x, Math.round(parseFloat(r.t) * img.h) - y];
  }
  fs.writeFileSync(path.join(OUT, 'icons.json'), JSON.stringify(icons));
  return Object.keys(icons).length;
}

function main() {
  const cfg = loadConfig();
  if (!fs.existsSync(path.join(cfg.gamePath, 'rom'))) {
    console.error(`game not found at ${cfg.gamePath} (set gamePath in config.json)`);
    process.exit(1);
  }
  fs.mkdirSync(OUT, { recursive: true });
  const { sources, modDirs } = tileSources(cfg);
  const tiles = buildTiles(sources);
  const locations = buildLocations(playlistFiles(cfg, modDirs));
  const icons = buildIcons(cfg.gamePath);
  console.log(`tiles: ${tiles.count} (failed ${tiles.failed}), locations: ${locations}, mods: ${modDirs.length}, icons: ${icons}`);
}

if (require.main === module) main();

module.exports = { mergeSources };
