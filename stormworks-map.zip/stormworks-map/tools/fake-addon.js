// Sends the recorded fixtures to the map server the same way the in-game addon does.
//   npm run fake-addon [-- --port 37037]
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

function get(port, p) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: p }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve(body));
    }).on('error', reject);
  });
}

let counter = 0;

// Resolves with the server's reply to /sw/end ("ok" or "need:...").
async function sendMessage(port, obj, chunk = 1000) {
  const s = `${process.pid}-${++counter}`;
  const enc = encodeURIComponent(JSON.stringify(obj));
  const parts = [];
  for (let i = 0; i < enc.length; i += chunk) parts.push(enc.slice(i, i + chunk));
  await get(port, `/sw/begin?s=${s}&n=${parts.length}`);
  for (let i = 0; i < parts.length; i++) await get(port, `/sw/part?s=${s}&i=${i}&d=${parts[i]}`);
  return get(port, `/sw/end?s=${s}`);
}

async function main() {
  const at = process.argv.indexOf('--port');
  const port = at > 0 ? Number(process.argv[at + 1]) : require('../server/config').loadConfig().port;
  const dir = path.join(__dirname, '..', 'test', 'fixtures');
  for (const f of ['layout.json', 'addons.json', 'snapshot.json']) {
    const reply = await sendMessage(port, JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')));
    console.log(`${f}: ${reply}`);
  }
}

if (require.main === module) main().catch((e) => { console.error(e.message); process.exit(1); });

module.exports = { sendMessage };
