// Reassembles chunked addon messages:
//   /sw/begin?s=<id>&n=<count>   /sw/part?s=<id>&i=<k>&d=<data>   /sw/end?s=<id>
// The addon percent-encodes the whole JSON and then splits it, so a chunk can end inside
// a %XX escape. Query values passed to handle() must therefore be RAW (not yet decoded);
// decoding happens once, after joining.
const PENDING_MAX_AGE_MS = 60_000;
const MAX_PARTS = 10_000;

function createAssembler({ onComplete, log = () => {} }) {
  const pending = new Map();  // id -> { n, parts: [], at }

  const prune = (now) => {
    for (const [id, p] of pending) {
      if (now - p.at > PENDING_MAX_AGE_MS) {
        pending.delete(id);
        log(`snapshot ${id}: dropped, incomplete after ${PENDING_MAX_AGE_MS / 1000}s`);
      }
    }
  };

  function handle(pathname, query) {
    if (!pathname.startsWith('/sw/')) return false;
    const now = Date.now();
    prune(now);
    const id = query.s;
    const route = pathname.slice(4);

    if (route === 'begin') {
      const n = Number(query.n);
      if (!id || !Number.isInteger(n) || n < 1 || n > MAX_PARTS) { log(`snapshot begin: bad args`); return true; }
      pending.set(id, { n, parts: new Array(n), at: now });
      return true;
    }

    const p = pending.get(id);
    if (!p) { log(`snapshot ${id}: ${route} for unknown id, ignored`); return true; }

    if (route === 'part') {
      const i = Number(query.i);
      if (!Number.isInteger(i) || i < 0 || i >= p.n) { log(`snapshot ${id}: bad part index ${query.i}`); return true; }
      p.parts[i] = query.d ?? '';
    } else if (route === 'end') {
      pending.delete(id);
      const missing = [];
      for (let i = 0; i < p.n; i++) if (p.parts[i] === undefined) missing.push(i);
      if (missing.length) { log(`snapshot ${id}: missing parts ${missing.join(',')}, dropped`); return true; }
      let obj;
      try {
        obj = JSON.parse(decodeURIComponent(p.parts.join('')));
      } catch (e) {
        log(`snapshot ${id}: bad json/encoding (${e.message}), dropped`);
        return true;
      }
      if (!obj || typeof obj !== 'object' || Array.isArray(obj)) { log(`snapshot ${id}: not an object, dropped`); return true; }
      try {
        onComplete(obj.kind, obj, now);
      } catch (e) {
        log(`snapshot ${id}: could not store (${e.message})`);
      }
    } else {
      log(`snapshot: unknown route ${route}`);
    }
    return true;
  }

  return { handle };
}

// Splits "a=1&d=%7B..." without percent-decoding (see header comment).
function rawQuery(search) {
  const out = {};
  for (const pair of (search || '').replace(/^\?/, '').split('&')) {
    if (!pair) continue;
    const eq = pair.indexOf('=');
    out[eq < 0 ? pair : pair.slice(0, eq)] = eq < 0 ? '' : pair.slice(eq + 1);
  }
  return out;
}

module.exports = { createAssembler, rawQuery };
