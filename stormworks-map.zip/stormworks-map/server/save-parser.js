// Reads a Stormworks save (saves/<name>/scene.xml) into plain data for the map.
const fs = require('node:fs');
const path = require('node:path');
const { xmlParser, num, bool, pos } = require('../tools/lib/xml');

const OBJECT_FIRE = 58;

const arr = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);
const cells = (tiles) => arr(tiles?.tile).map((t) => ({ cx: num(t.value?.x), cy: num(t.value?.y) }));

function parseSave(text) {
  if (!/<\/scene>\s*$/.test(text)) throw new Error('save incomplete (no </scene>), game may be writing it');
  const scene = xmlParser.parse(text).scene || {};
  const gd = scene.game_data || {};

  const objects = arr(scene.dynamics?.pseudo_data?.object).map((o) => ({
    id: num(o.id),
    type: num(o.type),
    name: o.network_name || '',
    steamId: o.char_steam_id || '-1',
    isMission: bool(o.is_mission),
    ...pos(o.transform),
  }));

  return {
    game: {
      day: num(gd.day),
      month: num(gd.month),
      year: num(gd.year),
      dayTick: num(gd.day_tick),
      money: num(gd.currency),
      weather: num(gd.weather),
    },
    player: gd.player_pos ? { x: num(gd.player_pos.x), y: num(gd.player_pos.y), z: num(gd.player_pos.z) } : null,
    playlists: arr(gd.active_playlists?.playlist_name).map((p) => p.value),
    mods: arr(gd.active_mods?.mod_path).map((p) => p.value),
    purchasedTiles: cells(scene.tiles?.purchased_tiles),
    discoveredTiles: cells(scene.tiles?.discovered_tiles),
    vehicles: arr(scene.vehicles?.vehicle_data?.vehicle).map((v) => ({
      id: num(v.id),
      groupId: num(v.vehicle_group_id),
      isMission: bool(v.is_mission),
      isStatic: bool(v.is_static),
      tags: v.addon_tags || '',
      ...pos(v.transform),
    })),
    characters: objects,
    fires: [
      ...objects.filter((o) => o.type === OBJECT_FIRE).map(({ id, x, y, z }) => ({ id, x, y, z })),
      ...arr(scene.missions_global?.tracked_fires?.fire).map((f) => ({ id: num(f.id), ...pos(f.transform) })),
    ],
    zones: arr(scene.cargo?.zone).map((z) => ({
      id: num(z.unique_id),
      name: z.display_name || z.tags || '',
      tags: z.tags || '',
      radius: num(z.zone_radius),
      ...pos(z.transform),
    })),
    addonNodes: arr(gd.addon_nodes?.node).map((n) => ({ tags: n.tags || '', x: num(n.pos?.x), z: num(n.pos?.y) })),
  };
}

// dir -> { mtime, state }  (last good parse per save folder)
const cache = new Map();

function loadSave(dir) {
  const file = path.join(dir, 'scene.xml');
  const name = path.basename(dir);
  let mtime;
  try {
    mtime = fs.statSync(file).mtimeMs;
  } catch (e) {
    const prev = cache.get(dir);
    return { state: prev?.state ?? null, mtime: prev?.mtime ?? null, name, error: `cannot read save: ${e.message}` };
  }
  const prev = cache.get(dir);
  if (prev && prev.mtime === mtime) {
    // a remembered failure reports the time of the last good parse, not the bad file's
    return { state: prev.state, mtime: prev.error ? prev.goodMtime ?? null : mtime, name, error: prev.error };
  }
  try {
    const state = parseSave(fs.readFileSync(file, 'utf8'));
    cache.set(dir, { mtime, state });
    return { state, mtime, name };
  } catch (e) {
    const error = `cannot parse save: ${e.message}`;
    // remember the failure for this mtime so we don't reparse a bad file every refresh
    const goodMtime = prev ? (prev.error ? prev.goodMtime : prev.mtime) : null;
    cache.set(dir, { mtime, state: prev?.state ?? null, error, goodMtime });
    return { state: prev?.state ?? null, mtime: goodMtime, name, error };
  }
}

function listSaves(savesPath) {
  let dirs;
  try {
    dirs = fs.readdirSync(savesPath, { withFileTypes: true }).filter((d) => d.isDirectory());
  } catch {
    return [];
  }
  return dirs
    .map((d) => {
      try {
        return { name: d.name, mtime: fs.statSync(path.join(savesPath, d.name, 'scene.xml')).mtimeMs };
      } catch {
        return null;
      }
    })
    .filter(Boolean)
    .sort((a, b) => b.mtime - a.mtime);
}

module.exports = { parseSave, loadSave, listSaves };
