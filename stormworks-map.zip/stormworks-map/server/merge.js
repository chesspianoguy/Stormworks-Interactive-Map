// Combines the newest save with the last addon snapshot into the state the page draws.
// Live sections (players, vehicles, characters, fires, game) come from whichever source is
// newer; zones and owned tiles only exist in the save.

const fromSave = {
  players: (s) => (s.player ? [{ name: 'player', ...s.player }] : []),
  vehicles: (s) => s.vehicles,
  characters: (s) => s.characters,
  fires: (s) => s.fires,
  game: (s) => s.game,
};
const fromSnap = {
  players: (n) => n.players || [],
  vehicles: (n) => n.vehicles || [],
  characters: (n) => n.chars || [],
  fires: (n) => n.fires || [],
  game: (n) => n.game || {},
};

function merge({ save, saveTime, saveName, saveError, snap, snapTime, layout, addons }) {
  const useSnap = snap && (!save || snapTime > saveTime);
  const section = (key) => {
    if (useSnap) return { source: 'addon', time: snapTime, items: fromSnap[key](snap) };
    if (save) return { source: 'save', time: saveTime, items: fromSave[key](save) };
    return { source: null, time: null, items: key === 'game' ? {} : [] };
  };

  return {
    generated: Date.now(),
    sources: {
      addon: snap ? { time: snapTime } : null,
      save: save || saveError ? { name: saveName ?? null, time: saveTime ?? null, error: saveError } : null,
    },
    game: section('game'),
    players: section('players'),
    vehicles: section('vehicles'),
    characters: section('characters'),
    fires: section('fires'),
    zones: { source: save ? 'save' : null, time: saveTime ?? null, items: save ? save.zones : [] },
    purchasedTiles: save ? save.purchasedTiles : [],
    addonNodes: save ? save.addonNodes : [],
    tilesLayout: layout?.tiles ?? null,
    addons: addons?.addons ?? null,
  };
}

module.exports = { merge };
