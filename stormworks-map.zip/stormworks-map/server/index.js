// Local map server. Binds 127.0.0.1 only; never sends anything to the game.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { loadConfig, ROOT } = require('./config');
const { loadSave, listSaves } = require('./save-parser');
const { createAssembler, rawQuery } = require('./snapshot');
const { merge } = require('./merge');
const { tileName } = require('../tools/lib/playlist');

// Only this machine's own page and the game may talk to the server: refuse other sites
// (Origin / Sec-Fetch-Site) and other host names (DNS rebinding).
function allowed(req, port) {
  const own = new Set([`127.0.0.1:${port}`, `localhost:${port}`, '127.0.0.1', 'localhost']);
  const host = req.headers.host;
  if (host && !own.has(host.toLowerCase())) return false;
  const site = req.headers['sec-fetch-site'];
  if (site && site !== 'same-origin' && site !== 'none') return false;
  const origin = req.headers.origin;
  if (origin && !own.has(origin.toLowerCase().replace(/^http:\/\//, ''))) return false;
  return true;
}

// The addon may report tiles as "data/tiles/<name>.xml"; map data is keyed by bare name.
function normaliseTiles(kind, obj) {
  if (kind === 'layout') for (const t of obj.tiles || []) t.name = tileName(String(t.name));
  if (kind === 'addons') {
    for (const ad of obj.addons || []) for (const l of ad.locations || []) if (l.tile) l.tile = tileName(String(l.tile));
  }
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
};

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function sendJson(res, status, obj) {
  res.writeHead(status, { 'content-type': MIME['.json'], 'cache-control': 'no-store' });
  res.end(JSON.stringify(obj));
}

function sendText(res, status, text) {
  res.writeHead(status, { 'content-type': 'text/plain; charset=utf-8' });
  res.end(text);
}

// Serves files under `root`; anything resolving outside it is 403.
function serveStatic(res, root, rel) {
  let decoded;
  try { decoded = decodeURIComponent(rel); } catch { return sendText(res, 400, 'bad path'); }
  if (decoded.split(/[\\/]/).includes('..')) return sendText(res, 403, 'forbidden');
  const file = path.join(root, decoded);
  if (!file.startsWith(root + path.sep) && file !== root) return sendText(res, 403, 'forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return sendText(res, 404, 'not found');
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
    res.end(data);
  });
}

function startServer(cfg) {
  const log = cfg.quiet ? () => {} : (m) => console.log(`[${new Date().toLocaleTimeString()}] ${m}`);
  const webDir = cfg.webDir || path.join(ROOT, 'web');
  const mapDir = cfg.mapDir || path.join(ROOT, 'data', 'map');
  const cacheDir = cfg.cacheDir || path.join(ROOT, 'data', 'cache');
  fs.mkdirSync(cacheDir, { recursive: true });

  const live = {
    snap: null,
    snapTime: null,
    layout: readJson(path.join(cacheDir, 'layout.json')),
    addons: readJson(path.join(cacheDir, 'addons.json')),
  };

  const assembler = createAssembler({
    log,
    onComplete(kind, obj, at) {
      if (kind === 'snap') {
        live.snap = obj;
        live.snapTime = at;
      } else if (kind === 'layout' || kind === 'addons') {
        normaliseTiles(kind, obj);
        live[kind] = obj;
        fs.writeFileSync(path.join(cacheDir, `${kind}.json`), JSON.stringify(obj));
        log(`addon sent ${kind}`);
      } else {
        log(`addon sent unknown kind ${kind}`);
      }
    },
  });

  if (!fs.existsSync(path.join(mapDir, 'tiles.json'))) log('map data missing, run: npm run build-map');

  const server = http.createServer((req, res) => {
    if (!allowed(req, server.address().port)) return sendText(res, 403, 'forbidden');
    const qAt = req.url.indexOf('?');
    const pathname = qAt < 0 ? req.url : req.url.slice(0, qAt);
    const search = qAt < 0 ? '' : req.url.slice(qAt + 1);

    if (pathname.startsWith('/sw/')) {
      assembler.handle(pathname, rawQuery(search));
      const need = ['layout', 'addons'].filter((k) => !live[k]);
      return sendText(res, 200, pathname === '/sw/end' && need.length ? `need:${need.join(',')}` : 'ok');
    }

    if (req.method !== 'GET') return sendText(res, 405, 'method not allowed');

    if (pathname === '/api/saves') return sendJson(res, 200, listSaves(cfg.savesPath));

    if (pathname === '/api/state') {
      const saves = listSaves(cfg.savesPath);
      const wanted = new URLSearchParams(search).get('save');
      const pick = wanted ? saves.find((s) => s.name === wanted) : saves[0];
      if (wanted && !pick) return sendJson(res, 404, { error: `no save named ${wanted}` });
      const loaded = pick ? loadSave(path.join(cfg.savesPath, pick.name)) : null;
      // live data belongs to the world being played, which is the newest save
      const older = pick && pick !== saves[0];
      return sendJson(res, 200, merge({
        save: loaded?.state ?? null,
        saveTime: loaded?.mtime ?? null,
        saveName: loaded?.name,
        saveError: loaded?.error,
        ...live,
        ...(older ? { snap: null, snapTime: null } : {}),
      }));
    }

    if (pathname.startsWith('/map/')) return serveStatic(res, mapDir, pathname.slice(5));
    return serveStatic(res, webDir, pathname === '/' ? 'index.html' : pathname.slice(1));
  });

  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(cfg.port, '127.0.0.1', () => {
      log(`map at http://127.0.0.1:${server.address().port}/`);
      resolve(server);
    });
  });
}

if (require.main === module) {
  startServer(loadConfig()).catch((e) => {
    console.error(e.code === 'EADDRINUSE' ? 'port already in use, is the map server already running?' : e);
    process.exit(1);
  });
}

module.exports = { startServer };
