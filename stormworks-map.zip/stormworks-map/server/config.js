const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');

function expand(p) {
  return p.replace(/%([A-Z_]+)%/gi, (_, name) => process.env[name] ?? '');
}

function loadConfig(file = path.join(ROOT, 'config.json')) {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
  const cfg = { port: 37037, ...raw };
  for (const key of ['gamePath', 'savesPath', 'userAddonsPath', 'modsPath']) {
    if (cfg[key]) cfg[key] = expand(cfg[key]);
  }
  return cfg;
}

module.exports = { loadConfig, ROOT };
