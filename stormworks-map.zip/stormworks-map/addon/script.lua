-- sw-livemap: sends game state to the local map server (http://127.0.0.1:PORT).
-- View only: this script never changes the game. All calls are reads.

-- settings ------------------------------------------------------------------
PORT = 37037
CHUNK = 1000          -- max chars of data per request
SNAP_TICKS = 300      -- ticks between snapshots (300 = 5 s at 60 tps)
SCAN_PER_TICK = 200   -- max API calls per tick for scans
SEND_PER_TICK = 8     -- max httpGet calls per tick
VEH_SCAN_MAX = 4000   -- vehicle ids scanned 1..N
OBJ_SCAN_MAX = 8000   -- object ids scanned 1..N
TILE_RANGE = 130      -- tile scan covers -N..N cells (1 cell = 1000 m) on x and z
SKIP_TILE = "ocean"   -- tile names containing this are not sent
CHAR_TYPES = { [1] = true, [59] = true }  -- object types sent as characters (1 = character, 59 = creature)
FIRE_TYPE = 58

-- json ----------------------------------------------------------------------
local ARRAY = {}
local function A(t) t = t or {}; t[ARRAY] = true; return t end

local function json_str(s)
	s = tostring(s)
	s = s:gsub('[%c"\\]', function(c)
		if c == '"' then return '\\"' end
		if c == '\\' then return '\\\\' end
		if c == '\n' then return '\\n' end
		if c == '\r' then return '\\r' end
		if c == '\t' then return '\\t' end
		return string.format('\\u%04x', string.byte(c))
	end)
	return '"' .. s .. '"'
end

local function json(v)
	local t = type(v)
	if t == "nil" then return "null" end
	if t == "boolean" then return v and "true" or "false" end
	if t == "number" then
		if v ~= v or v == math.huge or v == -math.huge then return "null" end
		if math.type(v) == "integer" or v == math.floor(v) and math.abs(v) < 1e15 then return string.format("%d", v) end
		return string.format("%.2f", v)
	end
	if t == "string" then return json_str(v) end
	if t == "table" then
		local out = {}
		if v[ARRAY] or #v > 0 then
			for i = 1, #v do out[i] = json(v[i]) end
			return "[" .. table.concat(out, ",") .. "]"
		end
		for k, val in pairs(v) do
			if k ~= ARRAY then out[#out + 1] = json_str(k) .. ":" .. json(val) end
		end
		return "{" .. table.concat(out, ",") .. "}"
	end
	return "null"
end

local function url_encode(s)
	return (s:gsub("[^%w%-_%.~]", function(c) return string.format("%%%02X", string.byte(c)) end))
end

-- sending -------------------------------------------------------------------
local queue = {}      -- pending request paths
local snap_id = 0

local function send(msg)
	local enc = url_encode(json(msg))
	snap_id = snap_id + 1
	local s = tostring(snap_id)
	local n = math.max(1, math.ceil(#enc / CHUNK))
	queue[#queue + 1] = "/sw/begin?s=" .. s .. "&n=" .. n
	for i = 0, n - 1 do
		queue[#queue + 1] = "/sw/part?s=" .. s .. "&i=" .. i .. "&d=" .. enc:sub(i * CHUNK + 1, (i + 1) * CHUNK)
	end
	queue[#queue + 1] = "/sw/end?s=" .. s
end

local function flush()
	local sent = 0
	while #queue > 0 and sent < SEND_PER_TICK do
		server.httpGet(PORT, table.remove(queue, 1))
		sent = sent + 1
	end
end

-- jobs: step-wise scans so no tick does more than SCAN_PER_TICK calls -------
local jobs = {}       -- name -> coroutine-free state table with step()
local vehicle_peer = {}
-- ids only grow; spawn/load callbacks raise the scan limit past VEH/OBJ_SCAN_MAX
local max_vehicle_id, max_object_id = 0, 0
local ID_MARGIN = 100

local function pos_of(m)
	local x, y, z = matrix.position(m)
	return x, y, z
end

local function new_layout_job()
	local j = { cx = -TILE_RANGE, cy = -TILE_RANGE, tiles = A() }
	function j.step()
		for _ = 1, SCAN_PER_TICK do
			local tile, ok = server.getTile(matrix.translation(j.cx * 1000, 0, j.cy * 1000))
			if tile and ok ~= false and tile.name and tile.name ~= "" and not tile.name:find(SKIP_TILE, 1, true) then
				local t = { cx = j.cx, cy = j.cy, name = tile.name }
				if tile.purchased then t.purchased = true end
				if tile.cost and tile.cost > 0 then t.cost = tile.cost end
				j.tiles[#j.tiles + 1] = t
			end
			j.cx = j.cx + 1
			if j.cx > TILE_RANGE then
				j.cx = -TILE_RANGE
				j.cy = j.cy + 1
				if j.cy > TILE_RANGE then
					send({ kind = "layout", tiles = j.tiles })
					return true
				end
			end
		end
		return false
	end
	return j
end

local function new_addons_job()
	local j = { a = 0, l = 0, count = server.getAddonCount(), addons = A(), cur = nil }
	function j.step()
		local calls = 0
		while calls < SCAN_PER_TICK do
			if j.a >= j.count then
				send({ kind = "addons", addons = j.addons })
				return true
			end
			local ad = server.getAddonData(j.a)
			if not j.cur then
				j.cur = { index = j.a, name = ad and ad.name or ("addon " .. j.a), locations = A() }
				j.addons[#j.addons + 1] = j.cur
			end
			local loc_count = ad and ad.location_count or 0
			if j.l >= loc_count then
				j.a, j.l, j.cur = j.a + 1, 0, nil
			else
				local ld = server.getLocationData(j.a, j.l)
				calls = calls + 2
				if ld and ld.tile and ld.tile ~= "" then
					local origin, found = server.getTileTransform(matrix.translation(0, 0, 0), ld.tile, 200000)
					local loc = { name = ld.name or "", tile = ld.tile, components = A() }
					if found then
						loc.x, loc.y, loc.z = pos_of(origin)
						for c = 0, (ld.component_count or 0) - 1 do
							local cd = server.getLocationComponentData(j.a, j.l, c)
							calls = calls + 1
							if cd and cd.transform then
								local x, y, z = pos_of(matrix.multiply(origin, cd.transform))
								loc.components[#loc.components + 1] = {
									name = (cd.display_name ~= "" and cd.display_name) or cd.tags_full or "",
									type = cd.type, tags = cd.tags_full or "", x = x, y = y, z = z,
								}
							end
						end
					else
						loc.x = nil  -- tile not in this world; page skips it
					end
					j.cur.locations[#j.cur.locations + 1] = loc
				end
				j.l = j.l + 1
			end
			calls = calls + 1
		end
		return false
	end
	return j
end

local function new_snap_job()
	local j = { phase = "veh", id = 1, vehicles = A(), chars = A(), fires = A(),
		veh_max = math.max(VEH_SCAN_MAX, max_vehicle_id + ID_MARGIN), obj_max = math.max(OBJ_SCAN_MAX, max_object_id + ID_MARGIN) }
	function j.step()
		local calls = 0
		while calls < SCAN_PER_TICK do
			if j.phase == "veh" then
				if j.id > j.veh_max then
					j.phase, j.id = "obj", 1
				else
					local m, ok = server.getVehiclePos(j.id)
					calls = calls + 1
					if ok then
						local d = server.getVehicleData(j.id) or {}
						calls = calls + 1
						local x, y, z = pos_of(m)
						j.vehicles[#j.vehicles + 1] = {
							id = j.id, name = d.name or d.filename or "", peer = vehicle_peer[j.id] or -1,
							x = x, y = y, z = z, mass = d.mass, voxels = d.voxels, loaded = d.simulating == true,
						}
					end
					j.id = j.id + 1
				end
			elseif j.phase == "obj" then
				if j.id > j.obj_max then
					j.phase = "done"
				else
					local d = server.getObjectData(j.id)
					calls = calls + 1
					if d and (CHAR_TYPES[d.object_type] or d.object_type == FIRE_TYPE) then
						local m, ok = server.getObjectPos(j.id)
						calls = calls + 1
						if ok then
							local x, y, z = pos_of(m)
							if d.object_type == FIRE_TYPE then
								j.fires[#j.fires + 1] = { id = j.id, x = x, y = y, z = z, lit = server.getFireData(j.id) == true }
							else
								j.chars[#j.chars + 1] = { id = j.id, type = d.object_type, name = d.name or "", x = x, y = y, z = z, dead = d.dead == true }
							end
						end
					end
					j.id = j.id + 1
				end
			else
				local players = A()
				local first_m
				for _, p in pairs(server.getPlayers()) do
					local m, ok = server.getPlayerPos(p.id)
					if ok then
						first_m = first_m or m
						local x, y, z = pos_of(m)
						local entry = { peer = p.id, name = p.name, steam = tostring(p.steam_id), x = x, y = y, z = z,
							heading = math.atan(m[9], m[11]) }
						local cd = p.object_id and server.getCharacterData(p.object_id)
						if cd and cd.v_id then entry.vehicle = cd.v_id end
						players[#players + 1] = entry
					end
				end
				local clock = server.getTime() or {}
				local game = { hour = clock.hour, minute = clock.minute, money = server.getCurrency(), research = server.getResearchPoints() }
				if server.getDate then game.day, game.month, game.year = server.getDate() end
				if first_m then
					local w = server.getWeather(first_m) or {}
					game.weather = { fog = w.fog, rain = w.rain, wind = w.wind, temp = w.temp }
				end
				send({ kind = "snap", game = game, players = players, vehicles = j.vehicles, chars = j.chars, fires = j.fires })
				return true
			end
		end
		return false
	end
	return j
end

-- callbacks -----------------------------------------------------------------
local tick = 0

function onCreate(is_world_create)
	queue, jobs, tick = {}, {}, 0
	jobs.layout = new_layout_job()
	jobs.addons = new_addons_job()
end

function onVehicleSpawn(vehicle_id, peer_id)
	vehicle_peer[vehicle_id] = peer_id
	max_vehicle_id = math.max(max_vehicle_id, vehicle_id)
end

function onVehicleLoad(vehicle_id)
	max_vehicle_id = math.max(max_vehicle_id, vehicle_id)
end

function onObjectLoad(object_id)
	max_object_id = math.max(max_object_id, object_id)
end

function onVehicleDespawn(vehicle_id)
	vehicle_peer[vehicle_id] = nil
end

function onTick()
	tick = tick + 1
	if tick % SNAP_TICKS == 0 and not jobs.snap then jobs.snap = new_snap_job() end
	-- one job step per tick, in a fixed order
	for _, name in ipairs({ "layout", "addons", "snap" }) do
		local j = jobs[name]
		if j then
			if j.step() then jobs[name] = nil end
			break
		end
	end
	flush()
end

function httpReply(port, request, reply)
	if port ~= PORT or type(reply) ~= "string" then return end
	if reply:find("need:", 1, true) then
		if reply:find("layout", 1, true) and not jobs.layout then jobs.layout = new_layout_job() end
		if reply:find("addons", 1, true) and not jobs.addons then jobs.addons = new_addons_job() end
	end
end
