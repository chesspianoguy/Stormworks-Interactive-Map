// Pure functions: server state -> marker lists per layer. No Leaflet here (tested in Node).

export const LAYER_IDS = ['tiles', 'locBase', 'locMods', 'zones', 'players', 'vehicles', 'npcs', 'fires', 'owned'];

export const LAYER_NAMES = {
  tiles: 'Tiles',
  locBase: 'Locations (game)',
  locMods: 'Locations (mods/addons)',
  zones: 'Mission zones',
  players: 'Players',
  vehicles: 'Vehicles',
  npcs: 'NPCs & creatures',
  fires: 'Fires',
  owned: 'Owned tiles',
};

export const NPC_TYPES = [1, 59];  // object types: character, creature
export const TILE_SIZE = 1000;

// Game names come from players and mods; Leaflet tooltips/labels take HTML, so escape them.
const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);

export const worldToLatLng = (x, z) => [z, x];
export const tileOrigin = (cx, cy) => ({ x: cx * TILE_SIZE, z: cy * TILE_SIZE });

// name -> first layout cell with that tile
function tileIndex(layout) {
  const m = new Map();
  for (const t of layout || []) if (!m.has(t.name)) m.set(t.name, t);
  return m;
}

const item = (layer, x, z, icon, title, info) => ({ layer, latlng: worldToLatLng(x, z), icon, title, info });

function vehicleIcon(v) {
  if (v.y < -5) return 'sub';
  return 'vehicle';
}

// Builder locations are tile-local; the addon's are already world positions.
function locationItems(state, builderLocations, tiles) {
  const base = [];
  const mods = [];
  const push = (it) => (it.info.source === 'base' ? base : mods).push(it);

  if (state.addons) {
    const sourceOf = new Map(builderLocations.map((l) => [l.addon, l.source]));
    for (const ad of state.addons) {
      const source = sourceOf.get(ad.name) || `mod:${ad.name}`;
      for (const loc of ad.locations || []) {
        const first = (loc.components || []).find((c) => c.x != null);
        const p = first || (loc.x != null ? loc : null);
        if (!p) continue;
        push(item('loc', p.x, p.z, 'missionmarker', loc.name, {
          name: loc.name, addon: ad.name, source, tile: loc.tile,
          components: (loc.components || []).map((c) => c.name).filter(Boolean).join(', '),
        }));
      }
    }
    return { base, mods };
  }

  for (const loc of builderLocations) {
    const cell = tiles.get(loc.tile);
    if (!cell) continue;
    const o = tileOrigin(cell.cx, cell.cy);
    const c = loc.components[0] || { x: 0, z: 0 };
    push(item('loc', o.x + c.x, o.z + c.z, 'missionmarker', loc.name, {
      name: loc.name, addon: loc.addon, source: loc.source, tile: loc.tile,
      components: loc.components.map((k) => k.name).filter(Boolean).join(', '),
    }));
  }
  return { base, mods };
}

export function buildLayers(state, builderLocations = []) {
  const tiles = tileIndex(state.tilesLayout);
  const out = Object.fromEntries(LAYER_IDS.map((id) => [id, []]));

  for (const t of state.tilesLayout || []) {
    const o = tileOrigin(t.cx, t.cy);
    out.tiles.push(item('tiles', o.x, o.z, null, t.name, { name: t.name, cell: `${t.cx},${t.cy}`, cost: t.cost || 0, purchased: !!t.purchased }));
  }

  const { base, mods } = locationItems(state, builderLocations, tiles);
  out.locBase = base.map((i) => ({ ...i, layer: 'locBase' }));
  out.locMods = mods.map((i) => ({ ...i, layer: 'locMods' }));

  for (const z of state.zones?.items || []) {
    out.zones.push(item('zones', z.x, z.z, 'cargo_pickup', z.name || `Zone ${z.id}`, { ...z }));
  }
  for (const p of state.players?.items || []) {
    out.players.push(item('players', p.x, p.z, 'playercircle', p.name || 'player', { ...p }));
  }
  for (const v of state.vehicles?.items || []) {
    out.vehicles.push(item('vehicles', v.x, v.z, vehicleIcon(v), v.name || v.tags || `Vehicle #${v.id}`, { ...v }));
  }
  for (const c of state.characters?.items || []) {
    if (!NPC_TYPES.includes(c.type)) continue;
    out.npcs.push(item('npcs', c.x, c.z, c.type === 1 ? 'survivoricon' : 'fish', c.name || (c.type === 1 ? 'Character' : 'Creature'), { ...c }));
  }
  for (const f of state.fires?.items || []) {
    out.fires.push(item('fires', f.x, f.z, 'fireicon', `Fire #${f.id}`, { ...f }));
  }

  const owned = new Map();
  for (const t of state.purchasedTiles || []) owned.set(`${t.cx},${t.cy}`, t);
  for (const t of state.tilesLayout || []) if (t.purchased) owned.set(`${t.cx},${t.cy}`, t);
  for (const [cell, t] of owned) {
    const o = tileOrigin(t.cx, t.cy);
    out.owned.push(item('owned', o.x, o.z, 'home_purchase', `Owned tile ${cell}`, { cell, name: t.name || '' }));
  }
  return out;
}

export function buildIndex(layers) {
  const idx = [];
  for (const [layer, items] of Object.entries(layers)) {
    for (const it of items) idx.push({ layer, item: it, key: String(it.title).toLowerCase() });
  }
  return idx;
}

export function search(index, q, max = 50) {
  const needle = q.trim().toLowerCase();
  if (!needle) return [];
  const out = [];
  for (const e of index) {
    if (e.key.includes(needle)) {
      out.push(e);
      if (out.length >= max) break;
    }
  }
  return out;
}
