// Page boot: fetch state once, draw layers. No timers or polling — refresh the page to update.
/* global L */
import { buildLayers, buildIndex, search, escapeHtml, LAYER_IDS, LAYER_NAMES, TILE_SIZE } from './markers.js';
import { GeometryLayer } from './geometry-layer.js';

const COLORS = {
  tiles: '#9fb3c8', locBase: '#f2a541', locMods: '#c77dff', zones: '#4cc9f0', players: '#ffffff',
  vehicles: '#ffd166', npcs: '#06d6a0', fires: '#ef476f', owned: '#4caf7a',
};
const DEFAULT_ON = new Set(['locBase', 'locMods', 'players', 'vehicles', 'npcs', 'fires', 'owned']);
const ICON_PX = 22;
const STORE_KEY = 'swmap.layers';

const $ = (id) => document.getElementById(id);

function store(get, value) {
  try {
    if (get) return JSON.parse(localStorage.getItem(STORE_KEY) || 'null');
    localStorage.setItem(STORE_KEY, JSON.stringify(value));
  } catch { /* storage unavailable */ }
  return null;
}

async function getJson(url, fallback = null) {
  try {
    const r = await fetch(url);
    return r.ok ? await r.json() : fallback;
  } catch {
    return fallback;
  }
}

function ago(ms) {
  if (ms == null) return '';
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 90) return `${s} s old`;
  if (s < 5400) return `${Math.round(s / 60)} min old`;
  if (s < 172800) return `${Math.round(s / 3600)} h old`;
  return `${Math.round(s / 86400)} days old`;
}

function badge(text, cls) {
  const b = document.createElement('span');
  b.className = `badge ${cls || ''}`;
  b.textContent = text;
  return b;
}

function renderHeader(state, saves, currentSave) {
  const src = $('sources');
  src.replaceChildren();
  const { addon, save } = state.sources;
  src.append(addon ? badge(`addon • ${ago(addon.time)}`, Date.now() - addon.time < 60_000 ? 'ok' : 'warn') : badge('addon not connected', 'bad'));
  if (save) src.append(badge(`save "${save.name}" • ${ago(save.time)}`, save.error ? 'bad' : ''));
  else src.append(badge('no save found', 'bad'));

  const g = state.game.items || {};
  const parts = [];
  if (g.year) parts.push(`${g.day}/${g.month}/${g.year}`);
  if (g.hour != null) parts.push(`${String(g.hour).padStart(2, '0')}:${String(g.minute ?? 0).padStart(2, '0')}`);
  if (g.money != null) parts.push(`$${Math.round(g.money).toLocaleString()}`);
  if (g.research != null) parts.push(`research ${g.research}`);
  if (g.weather) parts.push(`rain ${Math.round((g.weather.rain || 0) * 100)}% · wind ${Math.round((g.weather.wind || 0) * 100)}% · fog ${Math.round((g.weather.fog || 0) * 100)}%`);
  $('game').textContent = parts.join(' · ');

  const sel = $('save');
  sel.replaceChildren(...saves.map((s) => {
    const o = document.createElement('option');
    o.value = s.name;
    o.textContent = s.name;
    o.selected = s.name === (currentSave || state.sources.save?.name);
    return o;
  }));
  sel.onchange = () => {
    const u = new URL(location.href);
    u.searchParams.set('save', sel.value);
    location.href = u.toString();
  };

  const notes = [];
  if (save?.error) notes.push(save.error);
  if (!state.tilesLayout) notes.push('Tile positions unknown: run the game once with the sw-livemap addon enabled so it can scan the world. Live markers still show.');
  if (notes.length) {
    $('notice').textContent = notes.join(' — ');
    $('notice').hidden = false;
  }
}

function iconHtml(icons, name, color) {
  const r = icons[name];
  const wrap = `width:${ICON_PX + 6}px;height:${ICON_PX + 6}px;background:${color}`;
  if (!r) return `<span class="swi-wrap" style="${wrap}"></span>`;
  const [x, y, w, h] = r;
  const s = ICON_PX / Math.max(w, h);
  // icons are white glyphs; draw them dark on the colored disc
  return `<span class="swi-wrap" style="${wrap}"><span class="swi" style="width:${w * s}px;height:${h * s}px;`
    + `background-position:${-x * s}px ${-y * s}px;background-size:${1024 * s}px ${1024 * s}px;filter:brightness(0.15)"></span></span>`;
}

function showPanel(it) {
  $('panel-title').textContent = it.title;
  const rows = Object.entries(it.info).filter(([, v]) => v !== '' && v != null && typeof v !== 'object');
  $('panel-body').replaceChildren(...rows.map(([k, v]) => {
    const tr = document.createElement('tr');
    const a = document.createElement('td');
    const b = document.createElement('td');
    a.textContent = k;
    b.textContent = typeof v === 'number' && !Number.isInteger(v) ? v.toFixed(2) : String(v);
    tr.append(a, b);
    return tr;
  }));
  $('panel').hidden = false;
}

function makeMarker(it, icons, renderer) {
  const color = COLORS[it.layer];
  let m;
  if (it.layer === 'players' || it.layer === 'vehicles') {
    m = L.marker(it.latlng, {
      icon: L.divIcon({ html: iconHtml(icons, it.icon, color), className: '', iconSize: [ICON_PX + 6, ICON_PX + 6] }),
      zIndexOffset: it.layer === 'players' ? 1000 : 500,
    });
  } else if (it.layer === 'owned') {
    const [z, x] = it.latlng;
    const h = TILE_SIZE / 2;
    m = L.rectangle([[z - h, x - h], [z + h, x + h]], { renderer, color, weight: 2, fillOpacity: 0.12 });
  } else if (it.layer === 'zones') {
    m = L.circleMarker(it.latlng, { renderer, radius: 4, color, weight: 1, fillOpacity: 0.5 });
  } else {
    m = L.circleMarker(it.latlng, { renderer, radius: it.layer === 'tiles' ? 3 : 5, color: '#000', weight: 1, fillColor: color, fillOpacity: 0.9 });
  }
  m.bindTooltip(escapeHtml(it.title), { className: 'sw-label', direction: 'top' });
  m.on('click', () => showPanel(it));
  return m;
}

function setupSearch(map, index, markerOf) {
  const input = $('search');
  const list = $('results');
  let hits = [];
  const pick = (h) => {
    list.hidden = true;
    map.setView(h.item.latlng, Math.max(map.getZoom(), 0));
    markerOf.get(h.item)?.openTooltip();
    showPanel(h.item);
  };
  input.addEventListener('input', () => {
    hits = search(index, input.value);
    list.replaceChildren(...hits.map((h) => {
      const li = document.createElement('li');
      li.textContent = `${h.item.title} `;
      const sm = document.createElement('small');
      sm.textContent = LAYER_NAMES[h.layer];
      li.append(sm);
      li.onclick = () => pick(h);
      return li;
    }));
    list.hidden = !hits.length;
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && hits[0]) pick(hits[0]);
    if (e.key === 'Escape') list.hidden = true;
  });
}

async function main() {
  const saveParam = new URL(location.href).searchParams.get('save');
  const [state, saves, locations, icons] = await Promise.all([
    getJson(`/api/state${saveParam ? `?save=${encodeURIComponent(saveParam)}` : ''}`),
    getJson('/api/saves', []),
    getJson('/map/locations.json', []),
    getJson('/map/icons.json', {}),
  ]);
  if (!state) {
    $('notice').textContent = 'Could not load /api/state — is the map server running (npm start)?';
    $('notice').hidden = false;
    return;
  }
  renderHeader(state, saves, saveParam);

  const map = L.map('map', { crs: L.CRS.Simple, minZoom: -6, maxZoom: 3, zoomSnap: 0.5, preferCanvas: true, attributionControl: false });
  const renderer = L.canvas({ padding: 0.5 });
  if (state.tilesLayout) new GeometryLayer({ layout: state.tilesLayout, minZoom: -6, maxZoom: 3 }).addTo(map);

  const layers = buildLayers(state, locations);
  const saved = store(true);
  const overlays = {};
  const markerOf = new Map();
  const layerIdOf = new Map();  // layer group -> layer id
  for (const id of LAYER_IDS) {
    // mod locations get one toggle per mod/addon
    const split = id === 'locMods'
      ? Object.entries(Object.groupBy(layers[id], (it) => it.info.source))
      : [[null, layers[id]]];
    for (const [sub, items] of split) {
      if (!items.length && sub) continue;
      const g = L.layerGroup(items.map((it) => {
        const m = makeMarker(it, icons, renderer);
        markerOf.set(it, m);
        return m;
      }));
      const label = `${escapeHtml(sub ? sub.replace(/^(mod|user):/, '') : LAYER_NAMES[id])} <small>(${items.length})</small>`;
      overlays[sub ? `${LAYER_NAMES[id]}: ${label}` : label] = g;
      layerIdOf.set(g, id);
      const on = saved ? saved.includes(id) : DEFAULT_ON.has(id);
      if (on) g.addTo(map);
    }
  }
  L.control.layers(null, overlays, { collapsed: window.innerWidth < 700 }).addTo(map);
  map.on('overlayadd overlayremove', () => {
    const on = new Set();
    for (const [g, id] of layerIdOf) if (map.hasLayer(g)) on.add(id);
    store(false, [...on]);
  });

  $('panel-close').onclick = () => { $('panel').hidden = true; };
  setupSearch(map, buildIndex(layers), markerOf);

  const player = layers.players[0];
  if (player) map.setView(player.latlng, -1);
  else if (layers.tiles.length) map.fitBounds(L.latLngBounds(layers.tiles.map((t) => t.latlng)));
  else map.setView([0, 0], -4);
}

main();
