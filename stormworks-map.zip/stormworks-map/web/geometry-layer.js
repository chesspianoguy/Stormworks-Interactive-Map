// Leaflet canvas layer that draws the game's map geometry (data/map/tiles/<name>.json).
/* global L */
import { TILE_SIZE } from './markers.js';

// Mesh layer ids from tools/lib/geometry.js. Drawn in this order, over the deep-water background.
export const PALETTE = {
  deepWater: '#11293f',
  meshes: [
    [10, '#173652'],  // shallow water, farthest from coast
    [9, '#1c4161'],
    [8, '#224d71'],
    [7, '#2a5b82'],   // nearest coast
    [0, '#c8c1a4'],   // land
    [2, '#ddd09c'],   // sand
    [1, '#8ea36a'],   // grass
    [3, '#a6a69e'],   // rock / ice
    [6, '#99978e'],
    [5, '#7b786f'],   // cliff
    [4, '#f0f3f4'],   // snow
  ],
  lines: 'rgba(30, 30, 30, 0.55)',
  grid: 'rgba(255, 255, 255, 0.06)',
};

const LINE_MIN_ZOOM = -2;

export const GeometryLayer = L.GridLayer.extend({
  options: { tileSize: 256, layout: [], updateWhenZooming: false },

  initialize(options) {
    L.GridLayer.prototype.initialize.call(this, options);
    this._cache = new Map();  // tile name -> Promise<json|null>
    this._cells = new Map();  // "cx,cy" -> name
    for (const t of options.layout || []) this._cells.set(`${t.cx},${t.cy}`, t.name);
  },

  _geometry(name) {
    if (!this._cache.has(name)) {
      this._cache.set(name, fetch(`/map/tiles/${encodeURIComponent(name)}.json`).then((r) => (r.ok ? r.json() : null)).catch(() => null));
    }
    return this._cache.get(name);
  },

  createTile(coords, done) {
    const size = this.getTileSize();
    const canvas = L.DomUtil.create('canvas', 'sw-geo-tile');
    canvas.width = size.x;
    canvas.height = size.y;
    const ctx = canvas.getContext('2d');
    const map = this._map;
    const z = coords.z;
    const nw = map.unproject([coords.x * size.x, coords.y * size.y], z);
    const se = map.unproject([(coords.x + 1) * size.x, (coords.y + 1) * size.y], z);
    const west = nw.lng;
    const north = nw.lat;
    const scale = size.x / (se.lng - nw.lng);  // px per meter

    ctx.fillStyle = PALETTE.deepWater;
    ctx.fillRect(0, 0, size.x, size.y);

    // cells whose 1000 m square touches this canvas
    const half = TILE_SIZE / 2;
    const cx0 = Math.floor((west + half) / TILE_SIZE);
    const cx1 = Math.floor((se.lng + half) / TILE_SIZE);
    const cy0 = Math.floor((se.lat + half) / TILE_SIZE);
    const cy1 = Math.floor((north + half) / TILE_SIZE);
    const jobs = [];
    for (let cx = cx0; cx <= cx1; cx++) {
      for (let cy = cy0; cy <= cy1; cy++) {
        const name = this._cells.get(`${cx},${cy}`);
        if (name) jobs.push(this._geometry(name).then((g) => ({ g, cx, cy })));
      }
    }

    Promise.all(jobs).then((cells) => {
      const tx = (cx, x) => (cx * TILE_SIZE + x - west) * scale;
      const ty = (cy, zz) => (north - (cy * TILE_SIZE + zz)) * scale;
      for (const [id, color] of PALETTE.meshes) {
        ctx.fillStyle = color;
        ctx.beginPath();
        for (const { g, cx, cy } of cells) {
          const m = g?.meshes?.[id];
          if (!m || !m.i.length) continue;
          const v = m.v;
          for (let k = 0; k < m.i.length; k += 3) {
            const a = m.i[k] * 2, b = m.i[k + 1] * 2, c = m.i[k + 2] * 2;
            ctx.moveTo(tx(cx, v[a]), ty(cy, v[a + 1]));
            ctx.lineTo(tx(cx, v[b]), ty(cy, v[b + 1]));
            ctx.lineTo(tx(cx, v[c]), ty(cy, v[c + 1]));
            ctx.closePath();
          }
        }
        ctx.fill();
        // fill seams between adjacent triangles
        ctx.strokeStyle = color;
        ctx.lineWidth = 0.6;
        ctx.stroke();
      }
      if (z >= LINE_MIN_ZOOM) {
        ctx.strokeStyle = PALETTE.lines;
        ctx.lineWidth = Math.max(0.5, Math.min(1.5, scale * 2));
        ctx.beginPath();
        for (const { g, cx, cy } of cells) {
          for (const seg of g?.lines || []) {
            for (let k = 0; k < seg.length; k += 4) {
              ctx.moveTo(tx(cx, seg[k]), ty(cy, seg[k + 1]));
              ctx.lineTo(tx(cx, seg[k + 2]), ty(cy, seg[k + 3]));
            }
          }
        }
        ctx.stroke();
      }
      done(null, canvas);
    });
    return canvas;
  },
});
